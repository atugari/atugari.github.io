import {NICKNAME_FIRST,NICKNAME_SECOND} from './nicknames.js';
// Furigana (ruby) support for the Japanese display of the real online
// Othello. When the setting is on, kanji words on screen get a small
// reading above them; English is never touched.
//
// How it works: FURI_WORDS is a dictionary of the words actually used
// on screen, with their readings. rubyHtml() scans a string left to
// right and wraps the longest matching word at each position in a
// <ruby> tag. Compounds come before their parts (the list is sorted
// longest-first at load), because readings depend on context:
//   - 1手 is いって, not て; いい手 is いいて; 手番 is てばん
//   - 勝 in counts (3勝) is しょう, but 勝ち is かち and 勝敗 is しょうはい
//   - 引き分け is ひきわけ (the 分 inside is not ふん)
// Single kanji are guarded the way Nanpure does it
// (nanpure/releases/2026.11.05.100/furigana.js): a bare kanji never
// gets ruby inside a compound or a conjugation — it must stand alone
// (not next to kanji, and not followed by hiragana unless a particle
// follows). Known compounds are entered as whole words instead, and
// verb stems as their own entries (遊べ, 書い, 使え), as Nanpure does.
// 日 is deliberately left out: its reading depends on the whole number
// (2日 is ふつか, 3日 is みっか, 20日 is はつか), so a fixed reading
// would be wrong more often than right; it simply gets no ruby. 分 is
// in the dictionary with Nanpure's digit rule instead: ぷん after
// 0/1/3/4/6/8, ふん otherwise.
// This file has no DOM access at import time, so node tests can import it.
export const FURI_KEY='reversi-furigana-v1';
export function getFurigana(){
 try{
  if(typeof localStorage!=='undefined')return localStorage.getItem(FURI_KEY)==='1';
 }catch{}
 return false;
}
export function setFurigana(v){
 const on=!!v;
 try{if(typeof localStorage!=='undefined')localStorage.setItem(FURI_KEY,on?'1':'0');}catch{}
 return on;
}
// [word, reading]. Readings are hiragana only.
export const FURI_WORDS=[
 ['日本語','にほんご'],
 ['一戦','いっせん'],
 ['一時的','いちじてき'],
 ['読み込み直して','よみこみなおして'],
 ['通り','とおり'],
 ['夢','ゆめ'],
 ['水','みず'],
 ['沈む','しずむ'],
 ['月明かり','つきあかり'],
 ['灯台','とうだい'],
 ['夏','なつ'],
 ['霧','きり'],
 ['打ち上げ','うちあげ'],
 ['花火','はなび'],
 ['駆けっこ','かけっこ'],
 ['碁石','ごいし'],
 ['石','いし'],
 ['低い','ひくい'],
 ['神秘的','しんぴてき'],
 ['甘茶','あまちゃ'],
 ['音楽工房','おんがくこうぼう'],
 ['読み込み中','よみこみちゅう'],
 ['暗号化','あんごうか'],
 ['決まった','きまった'],
 ['一緒','いっしょ'],
 ['最長','さいちょう'],
 ['最初','さいしょ'],
 ['別人','べつじん'],
 ['番号','ばんごう'],
 ['名前','なまえ'],
 ['保存','ほぞん'],
 ['週間','しゅうかん'],
 ['月間','げっかん'],
 ['進行','しんこう'],
 ['端末','たんまつ'],
 ['情報','じょうほう'],
 ['文字','もじ'],
 ['自由','じゆう'],
 ['消える','きえる'],
 ['消え','きえ'],
 ['消す','けす'],
 ['取り消しました','とりけしました'],
 ['切断中','せつだんちゅう'],
 ['使用中','しようちゅう'],
 ['接続中','せつぞくちゅう'],
 ['待っています','まっています'],
 ['止まっています','とまっています'],
 ['お願いします','おねがいします'],
 ['引き分け','ひきわけ'],
 ['読み込み','よみこみ'],
 ['読み','よみ'],
 ['早打ち','はやうち'],
 ['取り消す','とりけす'],
 ['断りました','ことわりました'],
 ['達しました','たっしました'],
 ['変形盤面','へんけいばんめん'],
 ['変わった','かわった'],
 ['変わり','かわり'],
 ['大逆転','だいぎゃくてん'],
 ['未接続','みせつぞく'],
 ['接続先','せつぞくさき'],
 ['対戦中','たいせんちゅう'],
 ['連勝中','れんしょうちゅう'],
 ['対戦数','たいせんすう'],
 ['入れません','はいれません'],
 ['送って','おくって'],
 ['終わって','おわって'],
 ['待って','まって'],
 ['お試し','おためし'],
 ['探しています','さがしています'],
 ['見つかりませんでした','みつかりませんでした'],
 ['もう一度','もういちど'],
 ['見習い','みならい'],
 ['見習い位','みならいい'],
 ['駆け出し','かけだし'],
 ['駆け出し位','かけだしい'],
 ['上級者','じょうきゅうしゃ'],
 ['上級者位','じょうきゅうしゃい'],
 ['完全勝利','かんぜんしょうり'],
 ['本日','ほんじつ'],
 ['明日','あした'],
 ['今日','きょう'],
 ['以上','いじょう'],
 ['上限','じょうげん'],
 ['反映','はんえい'],
 ['復元','ふくげん'],
 ['応答','おうとう'],
 ['通信','つうしん'],
 ['操作','そうさ'],
 ['選択','せんたく'],
 ['確認','かくにん'],
 ['設定','せってい'],
 ['言語','げんご'],
 ['音量','おんりょう'],
 ['効果音','こうかおん'],
 ['効果','こうか'],
 ['盤面','ばんめん'],
 ['作成','さくせい'],
 ['参加','さんか'],
 ['部屋','へや'],
 ['部屋選択','へやせんたく'],
 ['記録','きろく'],
 ['称号','しょうごう'],
 ['主役','しゅやく'],
 ['順位','じゅんい'],
 ['今週','こんしゅう'],
 ['全体','ぜんたい'],
 ['接続','せつぞく'],
 ['切断','せつだん'],
 ['退出','たいしゅつ'],
 ['状態','じょうたい'],
 ['期限','きげん'],
 ['希望','きぼう'],
 ['返事','へんじ'],
 ['相手','あいて'],
 ['挨拶','あいさつ'],
 ['見事','みごと'],
 ['手番','てばん'],
 ['中堅','ちゅうけん'],
 ['中堅位','ちゅうけんい'],
 ['達人','たつじん'],
 ['達人位','たつじんい'],
 ['名手','めいしゅ'],
 ['名手位','めいしゅい'],
 ['覇者','はしゃ'],
 ['覇者位','はしゃい'],
 ['連勝','れんしょう'],
 ['連勝王','れんしょうおう'],
 ['勝敗','しょうはい'],
 ['勝ち','かち'],
 ['負け','まけ'],
 ['通常','つうじょう'],
 ['合計','ごうけい'],
 ['時間','じかん'],
 ['時間切れ','じかんぎれ'],
 ['時計','とけい'],
 ['残り','のこり'],
 ['場所','ばしょ'],
 ['自動','じどう'],
 ['停止','ていし'],
 ['受ける','うける'],
 ['断る','ことわる'],
 ['戻る','もどる'],
 ['送る','おくる'],
 ['送れ','おくれ'],
 ['流す','ながす'],
 ['鳴らす','ならす'],
 ['置く','おく'],
 ['置きます','おきます'],
 ['置ける','おける'],
 ['始め','はじめ'],
 ['誰も','だれも'],
 ['付き','つき'],
 ['人中','にんちゅう'],
 ['前に','まえに'],
 ['切れ','きれ'],
 ['使用','しよう'],
 ['変形','へんけい'],
 ['終了','しゅうりょう'],
 ['対戦','たいせん'],
 ['再読込','さいよみこみ'],
 ['再読込後','さいよみこみご'],
 ['再接続','さいせつぞく'],
 ['自動再接続','じどうさいせつぞく'],
 ['表示','ひょうじ'],
 ['空き','あき'],
 ['載って','のって'],
 ['1手','いって'],
 ['いい手','いいて'],
 ['形','かたち'],
 ['秒','びょう'],
 ['分','ふん'],
 ['局','きょく'],
 ['局以上','きょくいじょう'],
 ['点','てん'],
 ['位','い'],
 ['月','つき'],
 ['年','ねん'],
 ['戦','せん'],
 ['勝','しょう'],
 ['敗','はい'],
 ['黒','くろ'],
 ['白','しろ'],
 ['手','て'],
 ['音','おと'],
 ['仮','かり'],
 ['版','はん'],
 ['隅','すみ'],
 ['列','れつ'],
 ['行','ぎょう'],
 ['順','じゅん'],
 ['中','ちゅう'],
 ['後','ご'],
 // 追加分：画面に出る言葉で辞書になかったもの。読みは文脈で決まる
 // ものだけ注意：勝は数えるとき しょう、活用すると か（勝った・勝てば・
 // 勝っても・勝つと）。人は数えるとき にん（今3人が・人数・人中）、
 // 近くの人・遠くの人だけ ひと。入は入れる（いれた・入れられません）と
 // 入る（入ります・入れません）で読みが違うので形ごとに分けてある。
 ['置いた','おいた'],
 ['対','たい'],
 ['入れられません','いれられません'],
 ['考えています','かんがえています'],
 ['繋がりません','つながりません'],
 ['お待ちください','おまちください'],
 ['開かれました','ひらかれました'],
 ['見つかりません','みつかりません'],
 ['近くの人','ちかくのひと'],
 ['遠くの人','とおくのひと'],
 ['見られません','みられません'],
 ['問い合わせ','といあわせ'],
 ['勝っても','かっても'],
 ['入ります','はいります'],
 ['始まります','はじまります'],
 ['挑めます','いどめます'],
 ['勝った','かった'],
 ['勝てば','かてば'],
 ['勝つと','かつと'],
 ['勝とう','かとう'],
 ['入れた','いれた'],
 ['作られ','つくられ'],
 ['不具合','ふぐあい'],
 ['分かる','わかる'],
 ['新しく','あたらしく'],
 ['絵文字','えもじ'],
 ['裏返る','うらがえる'],
 ['変える','かえる'],
 ['続けて','つづけて'],
 ['送信','そうしん'],
 ['送信時刻','そうしんじこく'],
 ['送信中','そうしんちゅう'],
 ['順番','じゅんばん'],
 ['棋譜','きふ'],
 ['受付','うけつけ'],
 ['受付番号','うけつけばんごう'],
 ['決め','きめ'],
 ['同じ','おなじ'],
 ['少し','すこし'],
 ['画面','がめん'],
 ['回目','かいめ'],
 ['変動','へんどう'],
 ['半分','はんぶん'],
 ['大きい','おおきい'],
 ['上がり','あがり'],
 ['上がり幅','あがりはば'],
 ['上がった','あがった'],
 ['下がり','さがり'],
 ['下がり幅','さがりはば'],
 ['小さ','ちいさ'],
 ['普通','ふつう'],
 ['直近','ちょっきん'],
 ['良い','よい'],
 ['成績','せいせき'],
 ['下限','かげん'],
 ['大切','たいせつ'],
 ['内容','ないよう'],
 ['返信','へんしん'],
 ['必要','ひつよう'],
 ['場合','ばあい'],
 ['入力','にゅうりょく'],
 ['時刻','じこく'],
 ['項目','こうもく'],
 ['種類','しゅるい'],
 ['報告','ほうこく'],
 ['意見','いけん'],
 ['質問','しつもん'],
 ['改善','かいぜん'],
 ['任意','にんい'],
 ['目印','めじるし'],
 ['一覧','いちらん'],
 ['一番','いちばん'],
 ['歴代','れきだい'],
 ['勝率','しょうりつ'],
 ['王冠','おうかん'],
 ['優勝','ゆうしょう'],
 ['現在','げんざい'],
 ['公開','こうかい'],
 ['対応','たいおう'],
 ['言葉','ことば'],
 ['選ぶ','えらぶ'],
 ['絞る','しぼる'],
 ['広告','こうこく'],
 ['二人','ふたり'],
 ['人数','にんずう'],
 ['観戦','かんせん'],
 ['強さ','つよさ'],
 ['強い','つよい'],
 ['最強','さいきょう'],
 ['気軽','きがる'],
 ['本気','ほんき'],
 ['深く','ふかく'],
 ['全力','ぜんりょく'],
 ['試聴','しちょう'],
 ['好き','すき'],
 ['数字','すうじ'],
 ['漢字','かんじ'],
 ['使','つか'],
 ['使え','つかえ'],
 ['使う','つかう'],
 ['使い','つかい'],
 ['使い方','つかいかた'],
 ['使われ','つかわれ'],
 ['別','べつ'],
 ['他','ほか'],
 ['次','つぎ'],
 ['差','さ'],
 ['幅','はば'],
 ['終','おわ'],
 ['終わる','おわる'],
 ['終わり','おわり'],
 ['方','かた'],
 ['書','か'],
 ['書い','かい'],
 ['書か','かか'],
 ['遊','あそ'],
 ['遊べ','あそべ'],
 ['遊び方','あそびかた'],
 ['歯','は'],
 ['歯ごたえ','はごたえ'],
 ['読','よ'],
 ['人','にん'],
 ['今','いま'],
];
const SORTED=[...FURI_WORDS].sort((a,b)=>b[0].length-a[0].length);
const KANJI=/[一-龯々]/;
const HIRA=/[ぁ-ん]/;
// Particles that may follow a single-kanji word: Nanpure's list, plus
// ごと (5戦ごとに) and ほど (1分ほど), both particles in Japanese.
const PARTICLE=/^(?:を|が|に|で|の|は|も|と|へ|や|から|まで|です|ごと|ほど)/;
const PUN_DIGITS=/[013468０１３４６８]/;
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function formatReading(text, formatWord, formatCharacter){
 // Nanpure's way (nanpure/releases/2026.11.05.100/furigana.js): a single
 // kanji never gets ruby inside a longer kanji run or a conjugation.
 // The char before or after it must not be kanji, and if hiragana
 // follows it must start a particle, where the word stands alone
 // (3勝, 月の覇者, 5戦ごとに, 1分ほど). Multi-kanji words are reviewed
 // vocabulary with certain readings, so they are never blocked; known
 // compounds are entered as whole words instead (送信中, 受付番号,
 // 時間切れ), which is also how Nanpure handles them. 分 reads ぷん
 // after 0/1/3/4/6/8 (1分=いっぷん, 10分=じゅっぷん), ふん otherwise
 // (2分=にふん, 5分=ごふん) — Nanpure's digit rule. Bare 日 is left
 // out, as in Nanpure: its reading depends on the whole number.
 let out='',i=0;
 while(i<text.length){
  let hit=false;
  for(const [w,r] of SORTED){
   if(!text.startsWith(w,i))continue;
   // 月 after a digit is a month name (1月=いちがつ): allow it even
   // when kanji follows, and read it がつ (Nanpure's digit rule, the
   // same idea as 分 → ぷん after 0/1/3/4/6/8).
   const digitBefore=/[0-9０-９]/.test(text[i-1]||'');
   const monthAfterDigit=w==='月'&&digitBefore;
   const counterAfterDigit=digitBefore&&['月','分','戦'].includes(w);
   if(w.length===1&&KANJI.test(w)&&!counterAfterDigit){
    const before=text[i-1]||'',after=text[i+w.length]||'';
    if(KANJI.test(before)||KANJI.test(after))continue;
    if(HIRA.test(after)&&!PARTICLE.test(text.slice(i+1)))continue;
   }
   let reading=r;
   if(w==='分'&&PUN_DIGITS.test(text[i-1]||''))reading='ぷん';
   if(monthAfterDigit)reading='がつ';
   out+=formatWord(w,reading);i+=w.length;hit=true;break;
  }
  if(!hit){out+=formatCharacter(text[i]);i++;}
 }
 return out;
}
export function rubyHtml(text){
 return formatReading(text,(word,reading)=>'<ruby>'+esc(word)+'<rt>'+esc(reading)+'</rt></ruby>',esc);
}
// Render text into an element: ruby when the language is Japanese and
// the setting is on, plain text otherwise (English is never given ruby,
// and aria labels / the page title keep using plain text).
export function setText(el,text,lang,furiOn){
 if(!el)return;
 if(lang!=='ja'||!furiOn){el.textContent=text;return;}
 // Native dropdowns expose option labels as plain text. Keep the readings
 // next to their words so the label remains legible on desktop and mobile.
 if(el.tagName==='OPTION')el.textContent=formatReading(text,(word,reading)=>word+'（'+reading+'）',character=>character);
 else el.innerHTML=rubyHtml(text);
}
// Nickname furigana: only generated names get ruby. A generated name is
// FIRST + 'の' + SECOND from the nickname word lists (576 combinations,
// e.g. 青の猫); its readings are fixed, so ruby can be given. Free-input
// names get none: their readings cannot be guessed, and a dictionary
// match on a kanji inside them would be a guessed reading. Note the
// single-kanji entry 月 (つき) in FURI_WORDS above is for the word 月
// itself; a generated name is matched as a whole here, so it never
// falls back to that single-kanji reading.
// Readings for the two nickname word lists (hiragana only).
const NICK_FIRST_READINGS={青:'あお',赤:'あか',金:'きん',銀:'ぎん',月:'つき',星:'ほし',空:'そら',海:'うみ',山:'やま',川:'かわ',森:'もり',花:'はな',雪:'ゆき',風:'かぜ',雷:'かみなり',光:'ひかり',影:'かげ',虹:'にじ',桜:'さくら',竹:'たけ',松:'まつ',梅:'うめ',菊:'きく',桃:'もも'};
const NICK_SECOND_READINGS={猫:'ねこ',犬:'いぬ',狐:'きつね',兎:'うさぎ',鳥:'とり',亀:'かめ',蛙:'かえる',馬:'うま',羊:'ひつじ',猿:'さる',熊:'くま',狼:'おおかみ',鷹:'たか',鯉:'こい',蝶:'ちょう',蜂:'はち',蟹:'かに',蛇:'へび',鹿:'しか',象:'ぞう',鶴:'つる',鴨:'かも',鮫:'さめ',鯨:'くじら'};
export function isGeneratedNickname(name){
 if(typeof name!=='string')return false;
 const c=[...name];
 return c.length===3&&c[1]==='の'&&NICKNAME_FIRST.includes(c[0])&&NICKNAME_SECOND.includes(c[2]);
}
// Render a nickname as HTML for innerHTML: a generated name gets ruby on
// each kanji when the language is Japanese and furigana is on; any other
// name (free input, or any language / furigana off) is returned escaped
// with no ruby.
export function nicknameHtml(name,lang,furiOn){
 const e=esc(name);
 if(lang!=='ja'||!furiOn)return e;
 if(!isGeneratedNickname(name))return e;
 const c=[...name];
 return '<ruby>'+esc(c[0])+'<rt>'+NICK_FIRST_READINGS[c[0]]+'</rt></ruby>の<ruby>'+esc(c[2])+'<rt>'+NICK_SECOND_READINGS[c[2]]+'</rt></ruby>';
}
