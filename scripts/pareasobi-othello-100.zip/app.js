import {valid,move,counts,initBoard,pickVarShapeId} from './rules.js';
import {chooseCpuMove} from './cpu.js';
import {hasKey,translate,getLang,setLang,LANGS,LANG_NAMES,isRTL,ensureLang,languageMatches} from './i18n.js';
import {getFurigana,setFurigana,setText,rubyHtml,nicknameHtml} from './furigana.js';
import {initAds,refreshAds,adsEnabled} from './ads.js';
import {randomNickname,isValidNickname} from './nicknames.js';
import {CONTACT_TOPICS,CONTACT_CATEGORIES,CONTACT_VERSION,buildContactPayload,submitContact,saveContactReceipt} from './contact.js';
import {UPDATES} from './updates.js';
await ensureLang(getLang());
// Language: Japanese by default, saved in localStorage. Every
// user-visible string goes through t() or a data-i18n attribute; the
// only Japanese left in the client is the greeting phrases as sent
// values (the wire text stays Japanese so both players get the same
// words) — the button labels and the BGM/SE track names are translated.
let lang=getLang();
let furi=getFurigana();
const t=(k,v)=>translate(lang,k,v);
// Render screen text: ruby (furigana) on Japanese when the setting is
// on, plain text otherwise. English is never given ruby.
const tx=(el,text)=>setText(el,text,lang,furi);
// Set text that contains nicknames: each nickname in `nicks` is swapped
// for a placeholder before rubyHtml (so no dictionary word inside a
// nickname gets ruby), then the placeholder is swapped for the
// nickname's own HTML (ruby for generated names, plain for free input).
// The placeholder is a private-use character pair, which never appears
// in UI text or valid nicknames, and survives rubyHtml untouched.
const NICK_HOLDER='\uE000';
function txNick(el,text,nicks){
 const list=[...new Set((nicks||[]).filter(n=>typeof n==='string'&&n.length>0))].sort((a,b)=>[...b].length-[...a].length);
 let t=text;const holders=[];
 list.forEach((n,i)=>{
  const h=NICK_HOLDER+i+NICK_HOLDER;
  if(t.includes(n)){t=t.split(n).join(h);holders.push([h,n]);}
 });
 if(lang==='ja'&&furi){
  let html=rubyHtml(t);
  for(const [h,n] of holders)html=html.split(h).join(nicknameHtml(n,lang,furi));
  el.innerHTML=html;
 }else{
  let plain=t;
  for(const [h,n] of holders)plain=plain.split(h).join(n);
  el.textContent=plain;
 }
}
let names=[t('draw'),t('black'),t('white')];
const $=id=>document.getElementById(id),KEY='reversi-session-v1';
let session=null,state=null,ws=null,retries=0,timer=null,pending=false,manual=false,requesting=false,ackTimer=null,moveDeadlineAt=null,replaced=false,lastDeadlineSync=0;
// Which lobby sub-screen is open (null = the lobby itself): the contact
// form or the update history. draw() keeps the lobby hidden while one
// of them is open, so a state change never pops the lobby back.
let subScreen=null;
// Which top-level screen is open (test-play layout: one screen at a
// time): 'title' first, then 'menu' (the lobby), then one screen per
// job ('play', 'far', 'record', 'rankings', 'settings', 'twoplayer',
// 'local', 'cpu', 'cpushape'). The game
// screen is shown by draw() whenever a game is on, whatever this says.
// settingsReturn remembers where the settings back button goes when
// settings was opened mid-game ('game' then, the menu otherwise).
let screen='title';
let matchWasOn=false; // whether the game screen was shown on the last draw()
let settingsReturn=null;
function showScreen(name){
 screen=name;
 if(name!=='settings')settingsReturn=null;
 subScreen=null;
 draw();
 window.scrollTo(0,0);
 refreshAds();
 fetchOnlineCount();
 fetchHighlights();
}
function reasonText(){if(!state||!state.reason)return'';if(state.mode==='fast'&&state.reason==='timeout'&&state.winner)return t('reason_fast_timeout');const k='reason_'+state.reason;return hasKey(lang,k)?t(k):state.reason;}
const errorText=e=>{const k='err_'+String(e).toLowerCase();return hasKey(lang,k)?t(k):e;};
// Fast mode ends on a pool exhaustion, which is a timeout with a winner;
// show it as such instead of the raw reason code.
let lastSay='';
const say=s=>{lastSay=s;tx($('message'),s);};
// Countdown for the player to move. Normal mode: 20 seconds per move;
// slow mode: 60 seconds per move; both show the plain countdown below.
// Fast mode: the deadline is 3 free seconds plus the player's pool, so show
// the free seconds first and then the pool being used, plus both pools.
function livePool(p){
 if(!state||!state.pool)return 0;
 if(state.status!=='playing'||p!==state.currentPlayer||!moveDeadlineAt)return state.pool[p-1];
 // The clock is paused while the player is disconnected: show the stored pool.
 if(state.online&&state.online[p-1]===false)return state.pool[p-1];
 return Math.min(state.pool[p-1],Math.max(0,moveDeadlineAt-Date.now()));
}
function updateMoveTimer(){
 const el=$('move-timer');if(!el)return;
 const poolEl=$('pool');
 const bar=$('timer-bar');
 // The bar sits directly above the board in normal flow; hide it while
 // there is no countdown so it leaves no empty strip above the board
 // (local two-player and CPU play have no timer).
 const syncBar=()=>{if(bar)bar.hidden=!el.textContent&&!(poolEl&&poolEl.textContent);};
 if(!state||state.status!=='playing'||!moveDeadlineAt){el.textContent='';if(poolEl)poolEl.textContent='';syncBar();return;}
 // The clock is paused while the player to move is disconnected.
 if(state.online&&state.online[state.currentPlayer-1]===false){
  tx(el,t('timer_disconnected',{who:names[state.currentPlayer]}));
  if(poolEl&&state.mode==='fast')tx(poolEl,t('pool_line',{black:Math.ceil(state.pool[0]/1000),white:Math.ceil(state.pool[1]/1000)}));
  else if(poolEl)poolEl.textContent='';
  syncBar();
  return;
 }
 const left=Math.max(0,moveDeadlineAt-Date.now());
 // Safety net for a late or missing server alarm: when the local countdown
 // reaches zero, ask the server for a fresh snapshot (throttled) so the
 // server re-checks the deadlines and plays the timeout itself. The server
 // caps sync messages at 5 per 10 seconds per socket; one per 5 seconds
 // stays safely inside it.
 if(left<=0&&ws?.readyState===1){
  const now=Date.now();
  if(now-lastDeadlineSync>=5000){lastDeadlineSync=now;ws.send(JSON.stringify({type:'sync'}));}
 }
 if(state.mode==='fast'){
  const poolLive=livePool(state.currentPlayer);
  const freeLeft=Math.max(0,left-poolLive);
  tx(el,freeLeft>0?t('timer_left',{who:names[state.currentPlayer],seconds:Math.ceil(freeLeft/1000)}):t('timer_pool',{who:names[state.currentPlayer],seconds:Math.ceil(poolLive/1000)}));
  if(poolEl)tx(poolEl,t('pool_line',{black:Math.ceil(livePool(1)/1000),white:Math.ceil(livePool(2)/1000)}));
 }else{
  tx(el,t('timer_left',{who:names[state.currentPlayer],seconds:Math.ceil(left/1000)}));
  if(poolEl)poolEl.textContent='';
 }
 syncBar();
}
setInterval(updateMoveTimer,250);
// Fit the board into the height left on the game screen, so a match
// never slides: the board shrinks to the viewport instead of pushing
// the page into a scroll. The timer bar, player lines, greet panel and
// buttons keep their size; only the board gives way. The size is passed
// through --board-size so the board rule itself stays one line.
function fitBoard(){
 const game=$('game'),wrap=$('board-wrap');
 if(!game||!wrap||game.hidden)return;
 const r=wrap.getBoundingClientRect();
 // Never taller than the space left: no floor, so the board can never
 // stick out of its wrapper and cover the timer bar or the greet panel.
 const size=Math.max(0,Math.floor(Math.min(640,r.width,r.height)));
 game.style.setProperty('--board-size',size+'px');
}
// Refit whenever the game screen or its content changes size (timer bar
// showing, greet panel showing, rotation) and whenever the viewport
// itself changes size.
if(typeof ResizeObserver!=='undefined'){
 try{new ResizeObserver(()=>fitBoard()).observe($('board-wrap'));}catch{}
}
window.addEventListener('resize',fitBoard);
try{session=JSON.parse(sessionStorage.getItem(KEY));if(!/^[a-f0-9]{64}$/.test(session?.roomId)||!/^[a-f0-9]{64}$/.test(session?.token))session=null;}catch{}
// Player identity: a long-lived token in localStorage (no login). The room
// token is created fresh for every room, so it cannot carry a rating
// across games; this separate token is the player's identity. Only its
// hash is ever stored server-side.
const PID_KEY='reversi-player-v1';
let pid=null;
try{
 pid=localStorage.getItem(PID_KEY);
 if(!/^[a-f0-9]{64}$/.test(pid)){pid=Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');localStorage.setItem(PID_KEY,pid);}
}catch{pid=null;}
// Room password: 1-8 characters, any visible character. Same rules as the
// server (src/security.js); the server is the authority and re-checks.
// Counted in Unicode code points, so one kana is one character.
function badPasswordCodePoint(cp){
 return (cp>=0x00&&cp<=0x1f)||cp===0x7f||(cp>=0x80&&cp<=0x9f)
  ||(cp>=0x200b&&cp<=0x200f)||(cp>=0x202a&&cp<=0x202e)
  ||(cp>=0x2060&&cp<=0x2064)||cp===0xfeff;
}
function validPassword(pw){
 if(typeof pw!=='string')return false;
 const chars=[...pw];
 if(chars.length<1||chars.length>8)return false;
 if(pw.trim().length===0)return false;
 for(const ch of chars)if(badPasswordCodePoint(ch.codePointAt(0)))return false;
 return true;
}
// Audio: BGM and sound effects, self-hosted (the files in assets/ were
// downloaded from 甘茶の音楽工房 and ポケットサウンド, never hotlinked).
// Browsers block autoplay, so the BGM starts on the first tap or keypress.
const BGM_TRACKS=[
 {id:'yume',src:'assets/bgm-yume.mp3'},
 {id:'mizu',src:'assets/bgm-mizu.mp3'},
 {id:'todai',src:'assets/bgm-todai.mp3'},
 {id:'kiri',src:'assets/bgm-kiri.mp3'},
 {id:'moody',src:'assets/bgm-moody.mp3'},
 {id:'hanabi',src:'assets/bgm-hanabi.mp3'},
 {id:'happy',src:'assets/bgm-happy.mp3'},
 {id:'hiyoko',src:'assets/bgm-hiyoko.mp3'},
];
const PLACE_SES=[
 {id:'goisi',src:'assets/se-place-goisi.mp3'},
 {id:'ishi',src:'assets/se-place-ishi.mp3'},
 {id:'click',src:'assets/se-place-click.mp3'},
 {id:'lowbon',src:'assets/se-place-lowbon.mp3'},
 {id:'piko',src:'assets/se-place-piko.mp3'},
 {id:'pon',src:'assets/se-place-pon.mp3'},
 {id:'chirin',src:'assets/se-place-chirin.mp3'},
 {id:'gurokken',src:'assets/se-place-gurokken.mp3'},
];
const SE_FIXED={flip:'assets/se-flip.mp3',win:'assets/se-win.mp3'};
const AUDIO_KEY='reversi-audio-v1';
let audioSettings={bgmTrack:'yume',placeSe:'goisi',bgmVol:50,seVol:80,bgmOn:true,seOn:true};
try{const s=JSON.parse(localStorage.getItem(AUDIO_KEY));if(s&&typeof s==='object')audioSettings={...audioSettings,...s};}catch{}
const saveAudio=()=>{try{localStorage.setItem(AUDIO_KEY,JSON.stringify(audioSettings));}catch{}};
let bgmAudio=null,bgmStarted=false,bgmRetryTimer=null,bgmRetries=0;
function tryPlayBgm(){
 if(!bgmAudio||!bgmStarted||!audioSettings.bgmOn)return;
 const p=bgmAudio.play();
 if(p&&typeof p.catch==='function')p.catch(()=>{
  // The file may still be loading (a slow connection can refuse the
  // first play): try again a few times instead of staying silent.
  if(bgmRetries>=3)return;
  bgmRetries++;
  clearTimeout(bgmRetryTimer);
  bgmRetryTimer=setTimeout(()=>{tryPlayBgm();},1000);
 });
}
function applyBgm(){
 if(!bgmAudio){bgmAudio=new Audio();bgmAudio.loop=true;bgmAudio.preload='auto';}
 const t=BGM_TRACKS.find(x=>x.id===audioSettings.bgmTrack)||BGM_TRACKS[0];
 if(bgmAudio.dataset.track!==t.id){bgmAudio.src=t.src;bgmAudio.dataset.track=t.id;bgmAudio.load();}
 bgmAudio.volume=audioSettings.bgmVol/100;
 if(!audioSettings.bgmOn){bgmAudio.pause();return;}
 if(bgmStarted){bgmRetries=0;tryPlayBgm();}
}
// Warm the BGM file up at load so the first tap finds it buffered
// instead of waiting on a slow fetch (which can refuse the play).
applyBgm();
function startBgmOnce(){if(bgmStarted)return;bgmStarted=true;applyBgm();}
['pointerdown','keydown'].forEach(ev=>document.addEventListener(ev,startBgmOnce));
function playSe(src){
 if(!audioSettings.seOn)return;
 const a=new Audio(src);a.volume=audioSettings.seVol/100;a.play().catch(()=>{});
}
function playPlaceSe(){const s=PLACE_SES.find(x=>x.id===audioSettings.placeSe)||PLACE_SES[0];playSe(s.src);}
function playFlipSe(){playSe(SE_FIXED.flip);}
function playButtonSe(){/* Button presses make no sound (removed 2026-11-16). */}
function playEndSe(won){if(!won)return;playSe(SE_FIXED.win);}
// Sound-effect preview: plays the chosen sound once, even when the
// effects are off or the volume is 0 (at 0.8 then), so the sound can
// always be heard before choosing. The game itself still obeys the
// on/off switch and the volume.
function previewSe(src){
 const a=new Audio(src);a.volume=audioSettings.seOn&&audioSettings.seVol>0?audioSettings.seVol/100:0.8;a.play().catch(()=>{});
}
function previewPlaceSe(){const s=PLACE_SES.find(x=>x.id===audioSettings.placeSe)||PLACE_SES[0];previewSe(s.src);}
// The BGM / place-SE option labels come from the language table
// (bgm_* / se_*), so they switch with the language; the track ids and
// file names never change. Rebuilt on language change like the theme
// select, keeping the saved choice.
function renderAudioOptions(){
 const bt=$('bgm-track');if(bt){bt.replaceChildren();BGM_TRACKS.forEach(tr=>{const o=document.createElement('option');o.value=tr.id;o.textContent=t('bgm_'+tr.id);bt.append(o);});bt.value=audioSettings.bgmTrack;}
 const ps=$('place-se');if(ps){ps.replaceChildren();PLACE_SES.forEach(s=>{const o=document.createElement('option');o.value=s.id;o.textContent=t('se_'+s.id);ps.append(o);});ps.value=audioSettings.placeSe;}
}
function initAudioSettings(){
 renderAudioOptions();
 const bt=$('bgm-track');
 const ps=$('place-se');
 $('bgm-on').checked=audioSettings.bgmOn;
 $('se-on').checked=audioSettings.seOn;
 $('bgm-vol').value=audioSettings.bgmVol;
 $('se-vol').value=audioSettings.seVol;
 bt.onchange=()=>{audioSettings.bgmTrack=bt.value;saveAudio();applyBgm();};
 ps.onchange=()=>{audioSettings.placeSe=ps.value;saveAudio();playPlaceSe();};
 $('bgm-on').onchange=e=>{audioSettings.bgmOn=e.target.checked;saveAudio();applyBgm();};
 $('se-on').onchange=e=>{audioSettings.seOn=e.target.checked;saveAudio();};
 $('bgm-vol').oninput=e=>{audioSettings.bgmVol=+e.target.value;saveAudio();applyBgm();};
 $('se-vol').oninput=e=>{audioSettings.seVol=+e.target.value;saveAudio();};
 $('se-preview').onclick=()=>{playButtonSe();previewPlaceSe();};
 document.querySelectorAll('#se-preview-others [data-se]').forEach(b=>{b.onclick=()=>{playButtonSe();previewSe(SE_FIXED[b.dataset.se]);};});
 $('se-vol').onchange=()=>{previewPlaceSe();};
}
initAudioSettings();
// Play settings: confirm before placing a stone (off by default), saved in
// localStorage so it survives reopening the page.
const PLAY_KEY='reversi-play-v1';
let playSettings={confirmMove:false,showKifu:true};
try{const s=JSON.parse(localStorage.getItem(PLAY_KEY));if(s&&typeof s==='object')playSettings={...playSettings,...s};}catch{}
const savePlay=()=>{try{localStorage.setItem(PLAY_KEY,JSON.stringify(playSettings));}catch{}};
let confirmCell=null;
function initPlaySettings(){
 const c=$('confirm-move');c.checked=!!playSettings.confirmMove;
 c.onchange=e=>{playSettings.confirmMove=e.target.checked;savePlay();confirmCell=null;draw();};
 const k=$('kifu');if(k){k.checked=playSettings.showKifu!==false;k.onchange=e=>{playSettings.showKifu=e.target.checked;savePlay();draw();};}
}
initPlaySettings();
// Nickname: picked once, saved in the browser. Type any name in the
// input, or re-roll with the ランダム button. An invalid name (empty,
// over 12 characters, or with control characters) is not saved and the
// input goes back to the saved name. It travels to the server only
// with create/join and is shown to the opponent together with the
// rating; it is gone when the game ends.
const NICKNAME_KEY='reversi-nickname-v1';
let nickname=null;
try{nickname=localStorage.getItem(NICKNAME_KEY)||null;}catch{}
if(!nickname||!isValidNickname(nickname)){nickname=randomNickname();try{localStorage.setItem(NICKNAME_KEY,nickname);}catch{}}
function initNicknameSettings(){
 const input=$('nickname-input');if(!input)return;
 input.value=nickname||'';
 input.addEventListener('change',()=>{
  const v=input.value;
  if(isValidNickname(v)){nickname=v;try{localStorage.setItem(NICKNAME_KEY,nickname);}catch{}}
  else input.value=nickname||'';
 });
 input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();input.blur();}});
 const b=$('nickname-random');if(!b)return;
 b.onclick=()=>{playButtonSe();nickname=randomNickname();try{localStorage.setItem(NICKNAME_KEY,nickname);}catch{}input.value=nickname;};
}
initNicknameSettings();
// Language switch (settings): saved in localStorage, applies at once,
// including mid-game. Static text comes from data-i18n attributes;
// dynamic text is re-rendered by draw()/renderMine()/renderRankings().
function applyLang(){
 refreshLanguagePickers();
 document.documentElement.lang=lang;
 // Arabic reads right-to-left; every other language reads left-to-right.
 document.documentElement.dir=isRTL(lang)?'rtl':'ltr';
 document.title=t('app_title');
 names=[t('draw'),t('black'),t('white')];
 document.querySelectorAll('[data-i18n]').forEach(el=>{tx(el,t(el.dataset.i18n));});
 document.querySelectorAll('[data-i18n-aria]').forEach(el=>{el.setAttribute('aria-label',t(el.dataset.i18nAria));});
 const sel=$('lang');if(sel)sel.value=lang;
 const selTop=$('lang-top');if(selTop)selTop.value=lang;
 // Greeting phrase buttons are built once, so refresh their text here too.
 // The buttons show the translated label; the phrase sent to the
 // opponent stays the fixed Japanese text (see GREET_LABEL_KEYS).
 document.querySelectorAll('#greet-phrases button').forEach((b,i)=>{tx(b,t(GREET_LABEL_KEYS[i]));});
 // Keep the last status line in step when the display changes.
 tx($('message'),lastSay);
 // The contact form's kind/topic options and the update list are built
 // by script, so rebuild them too; the contact status line keeps its
 // last message in the new language.
 renderContactTopics();renderUpdates();
 renderRankFilter();
 renderThemeOptions();
 renderAudioOptions();
 if(contactStatus)tx($('contact-status'),t(contactStatus.key,contactStatus.vars));
 draw();renderMine();renderRankings(lastRankings);
 // The highlights re-render from the last fetch (a language switch
 // does not fetch again); a fresh fetch happens on the language
 // change itself and whenever the screen changes.
 if(lastHighlights){renderNews(lastHighlights);renderStreakKings(lastHighlights);renderMonthChamp(lastHighlights);}
}
const languagePickers=[];
function refreshLanguagePickers(){for(const {sel,search,count,render}of languagePickers){search.placeholder=t('language_search');search.setAttribute('aria-label',t('language_search'));sel.setAttribute('aria-label',t('lang_label'));render();}}
function initLangSettings(){for(const sel of [$('lang'),$('lang-top')]){if(!sel)continue;const search=document.createElement('input');search.type='search';search.id=sel.id+'-search';search.autocomplete='off';search.className='language-search';const count=document.createElement('small');count.setAttribute('aria-live','polite');const wrap=document.createElement('div');wrap.className='language-picker';sel.replaceWith(wrap);wrap.append(search,sel,count);const render=()=>{sel.replaceChildren();let n=0;for(const l of LANGS){if(!languageMatches(l,search.value))continue;const option=document.createElement('option');option.value=l;option.textContent=LANG_NAMES[l];sel.append(option);n++;}sel.value=lang;count.textContent=n+' / '+LANGS.length;};search.oninput=render;search.onkeydown=e=>{if(e.key==='Escape'){search.value='';render();}};let version=0;sel.onchange=async()=>{const next=sel.value;if(!LANGS.includes(next))return;const token=++version;wrap.setAttribute('aria-busy','true');try{await ensureLang(next);if(token!==version)return;lang=setLang(next);applyLang();fetchMe();fetchRankings();fetchHighlights();}catch(error){sel.value=lang;console.warn(error);}finally{if(token===version)wrap.removeAttribute('aria-busy');}};languagePickers.push({sel,search,count,render});render();}refreshLanguagePickers();}
initLangSettings();
// Theme (the test-play's six themes): saved in localStorage, applies at
// once, including mid-game. The board stays green in every theme.
const THEME_KEY='reversi-theme-v1';
const THEMES=['royal','emerald','sakura','noir','blueorange','highcontrast'];
let theme='royal';
try{const s=localStorage.getItem(THEME_KEY);if(THEMES.includes(s))theme=s;}catch{}
function applyTheme(){document.documentElement.dataset.theme=theme;}
applyTheme();
function renderThemeOptions(){
 const sel=$('theme');if(!sel)return;
 sel.replaceChildren();
 for(const id of THEMES){const o=document.createElement('option');o.value=id;tx(o,t('theme_'+id));sel.append(o);}
 sel.value=theme;
}
function initThemeSettings(){
 const sel=$('theme');if(!sel)return;
 renderThemeOptions();
 sel.onchange=()=>{if(THEMES.includes(sel.value)){theme=sel.value;try{localStorage.setItem(THEME_KEY,theme);}catch{}applyTheme();}};
}
initThemeSettings();
// Furigana (ruby) for Japanese display: off by default, saved in
// localStorage, applies at once (including mid-game) through applyLang.
function initFuriganaSettings(){
 const c=$('furigana');if(!c)return;
 c.checked=furi;
 c.onchange=()=>{furi=setFurigana(c.checked);applyLang();};
}
initFuriganaSettings();
// Send a message that needs no acknowledgement (greetings, rematch). Unlike
// send(), this never sets the pending flag, so a greeting cannot block a move.
function sendRaw(obj){
 if(!ws||ws.readyState!==1||!state||replaced)return;
 ws.send(JSON.stringify({id:crypto.randomUUID(),rev:state.rev,...obj}));
}
// Greetings: fixed phrases and a fixed set of 6 emoji only (no free text).
// Emoji appear only here; every other button stays words-only.
// The phrases sent over the wire stay the fixed Japanese text, so the
// server's check and both players' messages never change; only the
// button labels are translated (GREET_LABEL_KEYS, same order). The
// sender's language travels with the greeting, so the receiver shows
// the greeting in both languages: the sender's first, then the
// viewer's own in parentheses — e.g. a German opponent to a Japanese
// viewer shows "Viel Glück（よろしくお願いします）". When both
// languages match, or the sender's language is unknown (an older
// client), only one language is shown. Emoji are shown as-is.
const GREET_PHRASES=['よろしくお願いします','ありがとうございました','すみません','いい手ですね','お見事です'];
const GREET_LABEL_KEYS=['greet_hello','greet_thanks','greet_sorry','greet_goodmove','greet_brilliant'];
const GREET_EMOJI=['👋','👍','🎉','😢','🙏','😀'];
const GREET_COOLDOWN_MS=5000;
let lastGreetAt=0,greetClearTimer=null;
let rematchWaiting=false,rematchOfferFrom=null;
function greetDisplay(text,senderLang){
 const i=GREET_PHRASES.indexOf(text);
 if(i<0)return text;
 const key=GREET_LABEL_KEYS[i];
 const mine=t(key);
 if(typeof senderLang!=='string'||!LANGS.includes(senderLang))return mine;
 const theirs=translate(senderLang,key);
 return theirs===mine?mine:theirs+'（'+mine+'）';
}
function showGreet(from,text,senderLang){
 const el=$('greet-line');if(!el)return;
 tx(el,(from===session.color?t('greet_you'):t('greet_opponent'))+greetDisplay(text,senderLang));
 clearTimeout(greetClearTimer);greetClearTimer=setTimeout(()=>{el.textContent='';},5000);
}
function sendGreet(text){
 if(!ws||ws.readyState!==1||!state)return;
 if(Date.now()-lastGreetAt<GREET_COOLDOWN_MS){say(t('msg_greet_too_fast'));return;}
 lastGreetAt=Date.now();sendRaw({type:'greet',text,lang});showGreet(session.color,text,lang);
 document.querySelectorAll('#greet-panel button').forEach(b=>b.disabled=true);
 setTimeout(()=>document.querySelectorAll('#greet-panel button').forEach(b=>b.disabled=false),GREET_COOLDOWN_MS);
}
function initGreetPanel(){
 const ph=$('greet-phrases');
 GREET_PHRASES.forEach((phrase,i)=>{const b=document.createElement('button');b.type='button';tx(b,t(GREET_LABEL_KEYS[i]));b.onclick=()=>{playButtonSe();sendGreet(phrase);};ph.append(b);});
 const em=$('greet-emoji');
 GREET_EMOJI.forEach(t2=>{const b=document.createElement('button');b.type='button';b.textContent=t2;b.setAttribute('aria-label',t('greet_aria'));b.onclick=()=>{playButtonSe();sendGreet(t2);};em.append(b);});
}
initGreetPanel();
// Contact form and update history: lobby sub-screens. The form's
// kind/topic options are built from the tables in contact.js so the
// server's allowed values always match; the labels come from the
// language table.
const KIND_LABEL_KEY={question:'contact_kind_question',bug:'contact_kind_bug',suggestion:'contact_kind_suggestion',other:'contact_other'};
const TOPIC_LABEL_KEY={howto:'topic_howto',ranking:'rankings',language:'lang_label',display:'topic_display',input:'topic_input',usability:'topic_usability',rules:'topic_rules',accessibility:'topic_accessibility',other:'contact_other'};
let contactStatus=null; // {key, vars} of the last contact status line
function setContactStatus(key,vars){contactStatus=key?{key,vars}:null;const el=$('contact-status');if(!el)return;if(!contactStatus){el.textContent='';return;}tx(el,t(contactStatus.key,contactStatus.vars));}
function renderContactTopics(){
 const kindSel=$('contact-kind'),topicSel=$('contact-topic');if(!kindSel||!topicSel)return;
 const kind=CONTACT_CATEGORIES.includes(kindSel.value)?kindSel.value:'question';
 kindSel.replaceChildren();
 for(const c of CONTACT_CATEGORIES){const o=document.createElement('option');o.value=c;tx(o,t(KIND_LABEL_KEY[c]));kindSel.append(o);}
 kindSel.value=kind;
 const topics=CONTACT_TOPICS[kind]||['other'];
 const prev=topicSel.value;
 topicSel.replaceChildren();
 for(const tp of topics){const o=document.createElement('option');o.value=tp;tx(o,t(TOPIC_LABEL_KEY[tp]));topicSel.append(o);}
 if(topics.includes(prev))topicSel.value=prev;
}
function renderUpdates(){
 const list=$('updates-list');if(!list)return;
 list.replaceChildren();
 for(const u of UPDATES){
  const h=document.createElement('h3');
  tx(h,u.version+(u.date?' ('+u.date+')':'')+' '+t(u.titleKey));
  list.append(h);
  const ul=document.createElement('ul');
  for(const k of u.items){const li=document.createElement('li');tx(li,t(k));ul.append(li);}
  list.append(ul);
 }
}
// Opening a sub-screen hides the lobby; going back shows it again. The
// record, ranking and settings screens are top-level screens (see
// showScreen), and draw() keeps them hidden while a sub-screen is open.
function showSubScreen(which){
 subScreen=which;
 $('contact').hidden=which!=='contact';
 $('updates').hidden=which!=='updates';
 $('spectate').hidden=which!=='spectate';
 if(which==='contact')renderContactTopics();
 if(which==='updates')renderUpdates();
 if(which==='spectate')loadSpectateList();
 draw();
 if(which){const el=$(which);if(el&&el.scrollIntoView)el.scrollIntoView();}
 else window.scrollTo(0,0);
 refreshAds();
 fetchOnlineCount();
}
function initContact(){
 const kindSel=$('contact-kind');if(!kindSel)return;
 renderContactTopics();
 kindSel.onchange=()=>{renderContactTopics();};
 $('contact-open').onclick=()=>{playButtonSe();setContactStatus(null);showSubScreen('contact');};
 $('contact-back').onclick=()=>{playButtonSe();showSubScreen(null);};
 $('contact-send').onclick=async()=>{
  const sendBtn=$('contact-send');if(sendBtn.disabled)return;
  const built=buildContactPayload({category:$('contact-kind').value,topic:$('contact-topic').value,detail:$('contact-detail').value,email:$('contact-email').value,locale:lang,requestId:crypto.randomUUID(),version:CONTACT_VERSION});
  if(built.error){setContactStatus(built.error==='bad_email'?'contact_bad_email':'contact_invalid');return;}
  sendBtn.disabled=true;setContactStatus('contact_sending');
  const r=await submitContact(built.body);
  sendBtn.disabled=false;
  if(!r.ok){setContactStatus(r.status===429?'contact_too_fast':r.status===400?'contact_invalid':'contact_failed');return;}
  saveContactReceipt(r.id,r.accessKey);
  $('contact-detail').value='';$('contact-email').value='';
  setContactStatus('contact_sent',{id:r.id});
 };
 $('updates-open').onclick=()=>{playButtonSe();showSubScreen('updates');};
 $('updates-back').onclick=()=>{playButtonSe();showSubScreen(null);};
 renderUpdates();
}
initContact();
// A new game after a rematch: clear the previous game's result display and
// rematch state so the rating change is measured from this game on.
function onNewGame(){
 hideResultCeremony();
 endRatingShown=false;confirmCell=null;
 rematchWaiting=false;rematchOfferFrom=null;
 const rl=$('rematch-line');if(rl)rl.textContent='';
 const gl=$('greet-line');if(gl)gl.textContent='';
}
// Local two-player game (one device, two people): no server, no rating,
// no banner, no timer. The board, the shapes and the rules are the same
// as online play; the only difference is that both colours are played
// on this screen. The shape comes from the nearby screen's shape
// select, and a random pick is drawn fresh for each game, like the
// online rooms.
let localGame=null; // {board,currentPlayer,status,counts,winner,reason,passed,shape,history}
function startLocalGame(){
 const pick=$('local-shape').value;
 const shape=(pick==='wide'||pick==='heart'||pick==='donut'||pick==='diamond'||pick==='cross')?pick:'std';
 const board=initBoard(shape);
 localGame={board,currentPlayer:1,status:'playing',counts:counts(board),winner:null,reason:null,passed:[],shape,history:[]};
 hideResultCeremony();
 session=null;state=null;confirmCell=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;replaced=false;
 $('reconnect').hidden=true;
 try{sessionStorage.removeItem(KEY);}catch{}
 say('');draw();
}
function exitLocalGame(){hideResultCeremony();localGame=null;confirmCell=null;say('');showScreen('menu');}
function applyLocalMove(x,y){
 if(!localGame||localGame.status!=='playing')return;
 let r;try{r=move(localGame.board,x,y,localGame.currentPlayer);}catch{return;}
 Object.assign(localGame,{board:r.board,currentPlayer:r.currentPlayer,status:r.status,counts:r.counts,winner:r.winner,reason:r.reason,passed:r.passed});
 localGame.history.push([x,y]);
 playPlaceSe();if(r.changes.length>1)setTimeout(playFlipSe,120);
 if(r.status==='ended'&&r.winner)playEndSe(true);
 draw();
 if(r.status==='ended'){
  const word=ceremonyWordForColour(localGame.winner);
  if(word)showResultCeremony('local',localGame.board,word[0],word[1]);
 }
}
// CPU play (CPUとプレイ): the player (black) against this device's own
// engine (public/cpu.js). No server, no rating, no record, no timer,
// no banner — like the local two-player game, except the opponent is
// the CPU. The flow is the test play's: menu → strength (5 levels) →
// board (standard or a random variant shape) → play. The player is
// always black and moves first; the CPU answers after a short pause
// so the move can be seen.
let cpuGame=null; // {board,currentPlayer,status,counts,winner,reason,passed,shape,level,history,thinking}
let cpuLevel=3;
let cpuTimer=null;
function startCpuGame(){
 const pick=$('cpu-shape').value;
 const shape=(pick==='wide'||pick==='heart'||pick==='donut'||pick==='diamond'||pick==='cross')?pick:'std';
 const board=initBoard(shape);
 cpuGame={board,currentPlayer:1,status:'playing',counts:counts(board),winner:null,reason:null,passed:[],shape,level:cpuLevel,history:[],thinking:false};
 hideResultCeremony();
 session=null;state=null;localGame=null;confirmCell=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;replaced=false;
 $('reconnect').hidden=true;
 try{sessionStorage.removeItem(KEY);}catch{}
 say('');draw();
 maybeCpuMove();
}
function exitCpuGame(){hideResultCeremony();clearTimeout(cpuTimer);cpuGame=null;confirmCell=null;say('');showScreen('menu');}
function applyCpuPlayerMove(x,y){
 if(!cpuGame||cpuGame.status!=='playing'||cpuGame.currentPlayer!==1)return;
 let r;try{r=move(cpuGame.board,x,y,1);}catch{return;}
 Object.assign(cpuGame,{board:r.board,currentPlayer:r.currentPlayer,status:r.status,counts:r.counts,winner:r.winner,reason:r.reason,passed:r.passed});
 cpuGame.history.push([x,y]);
 playPlaceSe();if(r.changes.length>1)setTimeout(playFlipSe,120);
 if(r.status==='ended'&&r.winner)playEndSe(true);
 draw();
 if(r.status==='ended'){
  const word=ceremonyWordForYou(cpuGame.winner,1);
  if(word)showResultCeremony('cpu',cpuGame.board,word[0],word[1]);
 }
 maybeCpuMove();
}
function applyCpuMove(){
 if(!cpuGame||cpuGame.status!=='playing'||cpuGame.currentPlayer!==2)return;
 const m=chooseCpuMove(cpuGame.board,2,cpuGame.level);
 cpuGame.thinking=false;
 if(!m){draw();maybeCpuMove();return;}
 let r;try{r=move(cpuGame.board,m.x,m.y,2);}catch{draw();return;}
 Object.assign(cpuGame,{board:r.board,currentPlayer:r.currentPlayer,status:r.status,counts:r.counts,winner:r.winner,reason:r.reason,passed:r.passed});
 cpuGame.history.push([m.x,m.y]);
 playPlaceSe();if(r.changes.length>1)setTimeout(playFlipSe,120);
 if(r.status==='ended'&&r.winner)playEndSe(false);
 draw();
 if(r.status==='ended'){
  const word=ceremonyWordForYou(cpuGame.winner,1);
  if(word)showResultCeremony('cpu',cpuGame.board,word[0],word[1]);
 }
 maybeCpuMove();
}
// When it is the CPU's turn, show that it is thinking and answer after
// a short pause, so the move can be seen. A pass (no legal move) leaves
// the turn with the player, so this is a no-op then.
function maybeCpuMove(){
 clearTimeout(cpuTimer);
 if(!cpuGame||cpuGame.status!=='playing'||cpuGame.currentPlayer!==2)return;
 cpuGame.thinking=true;draw();
 cpuTimer=setTimeout(applyCpuMove,400);
}
// Ratings, ranks and rankings (fetched from the server; the rating service
// may be absent in local dev, in which case these stay silent).
const RANKS=[['rank_0',500,1],['rank_1',1000,2],['rank_2',1100,3],['rank_3',1200,4],['rank_4',1300,5],['rank_5',1400,6],['rank_6',1600,7]];
let myProfile=null,myRatingLoaded=false,rankScope='week',rankFilter=null,endRatingShown=false;
// The showcase count-up: the big rating number climbs from the last
// shown rating to the new one. With reduced motion it jumps at once,
// and a language switch (the same rating) does not replay it.
let lastShownRating=null,countRaf=0;
function animateCount(el,target){
 if(!el)return;
 if(reducedMotion()||lastShownRating===target){lastShownRating=target;tx(el,String(target));return;}
 const from=lastShownRating===null?0:lastShownRating;
 lastShownRating=target;
 cancelAnimationFrame(countRaf);
 const start=performance.now(),dur=800;
 const step=now=>{
  const k=Math.min(1,(now-start)/dur),e=1-Math.pow(1-k,3);
  tx(el,String(Math.round(from+(target-from)*e)));
  if(k<1)countRaf=requestAnimationFrame(step);
 };
 countRaf=requestAnimationFrame(step);
}
async function fetchMe(){if(!pid)return;try{const r=await fetch('api/me?lang='+lang,{headers:{'X-Player-Token':pid}});myRatingLoaded=true;if(!r.ok){renderMine();return;}myProfile=await r.json();renderMine();}catch{myRatingLoaded=true;renderMine();}}
function renderMine(){
 const el=$('my-rating');if(!el)return;
 if(!myProfile){tx(el,myRatingLoaded?t('rating_unavailable'):t('loading'));return;}
 const p=myProfile;
 // The showcase: a big gold rating that counts up, the rank big with
 // stars, the streaks and the score. The count-up replays only when
 // the rating itself changed (a language switch does not replay it).
 animateCount($('my-rating-num'),p.rating);
 lastShownRating=p.rating;
 tx($('my-rank-big'),t('rank_'+p.rank)+' '+'★'.repeat(p.stars));
 tx($('my-streak-line'),(p.streak>0?t('record_streak_now',{streak:p.streak}):t('record_streak_none'))+' / '+t('record_streak_best',{best:p.bestStreak||0})+' / '+t('record_streak_week',{week:p.weekBest||0}));
 tx($('my-score-line'),t('record_score',{wins:p.wins,losses:p.losses,drawsPart:p.draws?t('my_rating_draws',{draws:p.draws}):'',games:p.games}));
 tx(el,t('my_rating',{rating:p.rating,prov:p.provisional?t('provisional'):'',rank:t('rank_'+p.rank),stars:'★'.repeat(p.stars),wins:p.wins,losses:p.losses,drawsPart:p.draws?t('my_rating_draws',{draws:p.draws}):'',games:p.games})+(p.fastPending?' / '+t('fast_pending',{remaining:5-p.fastPending}):''));
 // Titles as gold chips, not one joined line.
 const titlesEl=$('my-titles');titlesEl.replaceChildren();
 if(!p.titles.length){tx(titlesEl,t('titles_none'));}
 else for(const x of p.titles){const c=document.createElement('span');c.className='title-chip';tx(c,x.name);titlesEl.append(c);}
 const lad=$('rank-ladder');lad.replaceChildren();
 RANKS.forEach(([name,min,stars],i)=>{const d=document.createElement('div');tx(d,t('rank_ladder',{stars:'★'.repeat(stars),name:t(name),min}));if(i===p.rank)d.className='rank-now';lad.append(d);});
}
function remainingText(endsAt){if(!endsAt)return'';const ms=Math.max(0,endsAt-Date.now()),d=Math.floor(ms/86400000),h=Math.floor(ms%86400000/3600000),m=Math.floor(ms%3600000/60000);return d>0?t('time_left_days',{days:d,hours:h}):t('time_left_hours',{hours:h,minutes:m});}
let lastRankings=null;
async function fetchRankings(){try{const r=await fetch('api/rankings?scope='+rankScope+(rankFilter===null?'':'&rank='+rankFilter),{headers:pid?{'X-Player-Token':pid}:{}});if(!r.ok)return;lastRankings=await r.json();renderRankings(lastRankings);}catch{}}
// Rank filter for the rankings: one dropdown next to the label
// (すべて + the seven ladder ranks), instead of eight buttons. The
// choice stays while the scope or the language changes.
function renderRankFilter(){
 const sel=$('rank-filter');if(!sel)return;
 sel.replaceChildren();
 const mk=(label,rank)=>{
  const o=document.createElement('option');o.value=rank===null?'all':String(rank);tx(o,label);sel.append(o);
 };
 mk(t('rank_filter_all'),null);
 for(let i=0;i<7;i++)mk(t('rank_'+i),i);
 sel.value=rankFilter===null?'all':String(rankFilter);
}
// Period (this week / this month / all) as one joined segment: the
// active period is gold, the others are navy.
function renderScopeButtons(){
 document.querySelectorAll('#rankings [data-scope]').forEach(b=>{b.classList.toggle('seg-active',b.dataset.scope===rankScope);});
}
function renderRankings(d){
 renderScopeButtons();
 if(!d)return;
 tx($('ranking-info'),d.scope==='week'?t('ranking_week',{left:remainingText(d.endsAt)}):d.scope==='month'?t('ranking_month',{left:remainingText(d.endsAt)}):t('ranking_all'));
 const ol=$('ranking-list');ol.replaceChildren();
 if(!d.entries.length){const li=document.createElement('li');tx(li,t('ranking_empty'));ol.append(li);}
 for(const e of d.entries){const li=document.createElement('li');let s=t(d.scope==='all'?'ranking_entry_all':'ranking_entry_period',{rank:e.rank,id:e.id,rating:e.rating,points:e.points,wins:e.wins,losses:e.losses,games:e.games});if(d.me&&e.id===d.me.id){s+=t('ranking_you');li.className='me-row';}tx(li,s);ol.append(li);}
 tx($('my-rank'),!d.me?'':d.me.rank?t('my_rank',{rank:d.me.rank,total:d.total}):(d.scope==='all'?'':t('my_rank_pending')));
}
// Highlights (streak kings, today's stars, streak news): one public
// read of the server, no token. When the server is unpublished or the
// fetch fails, the sections stay hidden (no made-up numbers).
let lastHighlights=null;
async function fetchHighlights(){
 try{
  const r=await fetch('api/highlights?lang='+lang);
  if(!r.ok)return;
  lastHighlights=await r.json();
  renderNews(lastHighlights);renderStreakKings(lastHighlights);renderMonthChamp(lastHighlights);
 }catch{}
}
// The current month's champion on the title screen: a gold crown, the
// nickname and the rating, under the dated title (2026年1月全体ランキング
// 優勝). With no champion yet this month the section stays hidden —
// no made-up name or rating is ever shown.
function renderMonthChamp(d){
 const box=$('month-champ');if(!box)return;
 const c=d&&d.monthChamp;
 if(!c||!c.name){box.hidden=true;return;}
 box.hidden=false;
 tx($('month-champ-title'),t('month_champ_title',{year:c.year,month:c.month}));
 const line=$('month-champ-line');line.replaceChildren();
 const crown=document.createElement('span');crown.className='crown';crown.setAttribute('aria-hidden','true');line.append(crown);
 const s=document.createElement('span');
 txNick(s,t('month_champ_line',{nick:c.name,rating:c.rating})+(c.provisional?t('provisional'):''),[c.name]);
 line.append(s);
}
// The news list on the title screen: current streaks first, then the
// weekly king, today's most wins, today's biggest gain — at most four
// rows, in that order (the same order the card uses). With no news the
// section shows an honest empty line instead of made-up rows.
function renderNews(d){
 const box=$('streak-news');if(!box)return;
 if(!d){box.hidden=true;return;}
 const rows=[];
 for(const s of d.streaks||[]){
  if(s&&s.name&&(s.count??0)>=3)rows.push({key:'news_streak_now',vars:{nick:s.name,count:s.count},nick:s.name});
 }
 if(d.weekKing&&d.weekKing.name)rows.push({key:'news_week_king',vars:{nick:d.weekKing.name,count:d.weekKing.count},nick:d.weekKing.name});
 if(d.todayWins&&d.todayWins.name)rows.push({key:'news_today_wins',vars:{nick:d.todayWins.name,count:d.todayWins.count},nick:d.todayWins.name});
 if(d.todayGain&&d.todayGain.name)rows.push({key:'news_today_gain',vars:{nick:d.todayGain.name,gain:d.todayGain.gain},nick:d.todayGain.name});
 const list=$('news-list');list.replaceChildren();
 for(const row of rows.slice(0,4)){
  const li=document.createElement('li');
  txNick(li,t(row.key,row.vars),[row.nick]);
  list.append(li);
 }
 box.hidden=false;
 $('news-empty').hidden=rows.length>0;
}
// The streak kings and today's stars on the rankings screen. A missing
// person shows an honest empty line; a provisional king or star is
// marked （仮）, the same as the streak king line.
function kingRow(el,label,king){
 const p=$(el);if(!p)return;
 p.replaceChildren();
 const lab=document.createElement('span');lab.className='king-label';tx(lab,label);p.append(lab);
 if(!king||!king.name){const e=document.createElement('span');tx(e,t('streak_king_empty'));p.append(e);return;}
 const crown=document.createElement('span');crown.className='crown';crown.setAttribute('aria-hidden','true');p.append(crown);
 const line=document.createElement('span');
 txNick(line,t('streak_king_line',{nick:king.name,streak:king.count})+(king.provisional?t('provisional'):''),[king.name]);
 p.append(line);
}
function starRow(el,key,entry){
 const p=$(el);if(!p)return;
 if(!entry||!entry.name){p.textContent='';return;}
 txNick(p,t(key,{nick:entry.name,wins:entry.count,gain:entry.gain})+(entry.provisional?t('provisional'):''),[entry.name]);
}
function renderStreakKings(d){
 if(!d)return;
 kingRow('streak-king-week',t('streak_king_week'),d.weekKing);
 kingRow('streak-king-all',t('streak_king_all'),d.allKing);
 const winsEl=$('today-star-wins'),gainEl=$('today-star-gain');
 if(!d.todayWins&&!d.todayGain){
  if(winsEl)tx(winsEl,t('today_star_empty'));
  if(gainEl)gainEl.textContent='';
  return;
 }
 starRow('today-star-wins','today_star_wins',d.todayWins);
 starRow('today-star-gain','today_star_gain',d.todayGain);
}
const save=()=>{try{sessionStorage.setItem(KEY,JSON.stringify(session));}catch{say(t('msg_no_restore'));}};
function clearPending(){pending=false;clearTimeout(ackTimer);}
// End-of-game ceremony （勝負が終わったときの演出）: when a game ends,
// after a short pause the board stones are taken off one by one, from
// the top-left, until the board is empty, while the stones are lined
// up in two trays — black stones in one tray, white stones in the
// other — black and white taking turns, and the black and white totals
// tick up big. When every stone is counted, the result appears big in
// the centre of the screen. This is only a display: the winner, the counts and
// the rating are decided by the rules and the server as before, and
// the ceremony runs once per game (ceremonyKey). Spectating uses
// onDone to leave after the word has been shown; the other modes leave
// the word up until the player starts a rematch or leaves.
let ceremonyTimer=null,ceremonyKey=null,ceremonyOnDone=null;
let ceremonyRemoved=0; // board stones taken off so far, top-left first
let ceremonyTrayBlack=0,ceremonyTrayWhite=0; // stones lined up in the two trays
const CEREMONY_STEP_MS=40,CEREMONY_WORD_MS=1600,CEREMONY_START_DELAY_MS=1000;
function ceremonyCells(board){
 const cells=[];
 for(let y=0;y<board.length;y++)for(let x=0;x<board[y].length;x++){
  if(board[y][x]===1||board[y][x]===2)cells.push({x,y,color:board[y][x]});
 }
 return cells;
}
// The board as it looks while the ceremony runs: the stones taken off
// so far are gone, the rest are still there. A fresh render (a redraw
// mid-ceremony, a settings round-trip) shows the same state.
function ceremonyBoardFor(board){
 const b=board.map(row=>row.slice());
 const cells=ceremonyCells(board);
 for(let i=0;i<ceremonyRemoved&&i<cells.length;i++)b[cells[i].y][cells[i].x]=0;
 return b;
}
// The next stone to line up: black and white take turns while both
// still have stones to line up; once one colour runs out, the rest of
// the other colour follows. Each stone goes into its own colour's
// tray (black into the black tray, white into the white tray), so each
// tray ends with the true total of its colour, and the numbers shown
// are the real ones.
function ceremonyNextTrayColor(total,black,white){
 if(black<total.black&&(white>=total.white||black<=white))return 1;
 return 2;
}
function reducedMotion(){
 try{return typeof matchMedia!=='undefined'&&matchMedia('(prefers-reduced-motion: reduce)').matches;}catch{return false;}
}
function hideResultCeremony(){
 clearTimeout(ceremonyTimer);ceremonyTimer=null;ceremonyKey=null;ceremonyOnDone=null;
 ceremonyRemoved=0;ceremonyTrayBlack=0;ceremonyTrayWhite=0;
 const o=$('result-overlay');if(o)o.hidden=true;
 const w=$('result-word');if(w)w.classList.remove('show');
 // The whole counting window goes away at once (its size never
 // changes while it is shown); the trays are emptied for the next game.
 const win=$('result-window');if(win)win.hidden=true;
 const trb=$('result-tray-black');if(trb)trb.replaceChildren();
 const trw=$('result-tray-white');if(trw)trw.replaceChildren();
}
// The centre word for a finished game. CPU and online play are from
// your side （勝ち / 負け / 引き分け）; local two-player and spectating
// have no "you", so the winner's colour is named （黒の勝ち / 白の勝ち）.
// A game with no winner (winner null) has no word and no ceremony.
function ceremonyWordForYou(winner,myColor){
 if(winner===null)return null;
 if(winner===0)return['result_draw',null];
 return winner===myColor?['result_you_win',null]:['result_you_lose',null];
}
function ceremonyWordForColour(winner){
 if(winner===null)return null;
 if(winner===0)return['result_draw',null];
 return['result_win',{who:names[winner]}];
}
function showResultCeremony(key,board,wordKey,wordVars,onDone){
 if(ceremonyKey===key)return false;
 if(!board||!Array.isArray(board))return false;
 const o=$('result-overlay');if(!o)return false;
 const total=counts(board);
 const cells=ceremonyCells(board);
 hideResultCeremony();
 ceremonyKey=key;ceremonyOnDone=onDone||null;
 ceremonyRemoved=0;ceremonyTrayBlack=0;ceremonyTrayWhite=0;
 const showWord=()=>{
  const word=$('result-word');tx(word,t(wordKey,wordVars));word.classList.add('show');
  o.hidden=false;
  ceremonyTimer=setTimeout(()=>{if(ceremonyOnDone){const f=ceremonyOnDone;ceremonyOnDone=null;f();}},CEREMONY_WORD_MS);
 };
 // One stone goes into its own colour's tray (black and white take
 // turns) and the matching total ticks up big above the board.
 const placeTrayStone=()=>{
  const color=ceremonyNextTrayColor(total,ceremonyTrayBlack,ceremonyTrayWhite);
  if(color===1){ceremonyTrayBlack++;tx($('result-black-num'),String(ceremonyTrayBlack));}
  else{ceremonyTrayWhite++;tx($('result-white-num'),String(ceremonyTrayWhite));}
  const tray=$(color===1?'result-tray-black':'result-tray-white');
  if(tray){const s=document.createElement('span');s.className='result-stone '+(color===1?'black':'white');tray.append(s);}
 };
 // One board stone comes off (top-left first) and one stone goes into
 // its colour's tray. When the board is empty and both trays are full,
 // the word appears big in the centre of the screen.
 const step=()=>{
  if(ceremonyKey!==key)return;
  if(ceremonyRemoved>=cells.length){showWord();return;}
  const c=cells[ceremonyRemoved];
  const cell=document.querySelector(`#board button[data-x="${c.x}"][data-y="${c.y}"]`);
  if(cell)cell.classList.remove('black','white');
  ceremonyRemoved++;
  placeTrayStone();
  ceremonyTimer=setTimeout(step,CEREMONY_STEP_MS);
 };
 // The counting window opens at its full size only when the lining-up
 // starts, never before: after the game ends there is a short pause
 // first, so the final board can be seen, and only then does the
 // window open and the first stone come off. The totals are reset
 // now and the board is drawn once so it loses its move numbers (the
 // ceremony key is already set, so a redraw shows the ceremony board).
 tx($('result-black-num'),'0');tx($('result-white-num'),'0');
 o.hidden=true;
 const w=$('result-word');if(w)w.classList.remove('show');
 draw();
 // The lining-up starts after a short pause. No animation when the
 // player asked for less motion, or when there is nothing to count:
 // take every stone off at once, line both trays up at once, and show
 // the final totals and the word at once.
 const begin=()=>{
  if(ceremonyKey!==key)return;
  const win=$('result-window');if(win)win.hidden=false;
  if(reducedMotion()||!cells.length){
   ceremonyRemoved=cells.length;
   while(ceremonyTrayBlack+ceremonyTrayWhite<cells.length)placeTrayStone();
   draw();
   showWord();
   return;
  }
  step();
 };
 ceremonyTimer=setTimeout(begin,CEREMONY_START_DELAY_MS);
 return true;
}
// Render the board cells (shared by the online game and the local
// two-player game): gaps outside the board shape, stones, hints for
// legal moves, and the confirm selection. onCell(x,y) runs when a legal
// cell is tapped and confirm mode is off. history (when given) is the
// list of moves in order; each stone shows its move number on top.
function renderBoard(board,hints,onCell,history){
 // While the end-of-game ceremony runs, the board shows the stones
 // still on it (the taken-off ones are gone) and no move numbers.
 if(ceremonyKey){board=ceremonyBoardFor(board);hints=[];history=null;}
 const boardEl=$('board');boardEl.replaceChildren();
 boardEl.style.gridTemplateColumns=`repeat(${board[0].length},1fr)`;
 for(let y=0;y<board.length;y++)for(let x=0;x<board[y].length;x++){
  const v=board[y][x];
  // -1 is a cell outside the board shape: show a gap, not a square.
  if(v===-1){const s=document.createElement('span');s.className='void';boardEl.append(s);continue;}
  const legal=hints.some(m=>m.x===x&&m.y===y),b=document.createElement('button');
  b.dataset.x=x;b.dataset.y=y;b.className=(v===1?'black':v===2?'white':'')+(legal?' hint':'')+(confirmCell&&confirmCell.x===x&&confirmCell.y===y?' confirm':'');
  b.setAttribute('aria-label',t('cell_label',{col:x+1,row:y+1,state:v?names[v]:t('empty')}));b.disabled=!legal;
  // Move numbers (棋譜): the four starting stones have no number; every
  // placed stone shows the number of the move that put it there.
  if(history&&v!==0){const n=history.findIndex(c=>c[0]===x&&c[1]===y);if(n>=0){const s=document.createElement('span');s.className='move-no';s.textContent=String(n+1);b.append(s);}}
  b.onclick=()=>{
   if(!playSettings.confirmMove){onCell(x,y);return;}
   // Confirm mode: tapping only selects the cell; the stone is placed by
   // the 「ここに置く」 button. Tapping another cell moves the selection.
   confirmCell={x,y};draw();
  };boardEl.append(b);
 }
}
// Draw the local two-player game: the same board as online play, but
// both colours are played here, so there is no timer, no presence, no
// rating and no banner.
function drawLocal(){
 const g=localGame;if(!g)return;
 $('reset').hidden=g.status!=='ended';
 const countsText=t('local_counts',{black:g.counts.black,white:g.counts.white});
 tx($('state'),g.status==='ended'?countsText+' / '+t('state_ended',{result:g.winner===null?t('result_none'):g.winner===0?t('result_draw'):t('result_win',{who:names[g.winner]})}):countsText+' / '+t('state_turn',{who:names[g.currentPlayer]}));
 tx($('move-timer'),'');tx($('pool'),'');
 const shapeKey='shape_'+g.shape;
 tx($('shape-info'),g.shape&&g.shape!=='std'?t('shape_info',{shape:hasKey(lang,shapeKey)?t(shapeKey):t('shape_unknown')}):'');
 $('leave').disabled=false;
 $('rematch').hidden=g.status!=='ended';
 $('rematch-cancel').hidden=true;$('rematch-offer').hidden=true;
 tx($('rematch-line'),'');
 const enabled=g.status==='playing';
 const hints=enabled?valid(g.board,g.currentPlayer):[];
 renderBoard(g.board,hints,(x,y)=>applyLocalMove(x,y),playSettings.showKifu!==false?g.history:null);
 const confirmValid=confirmCell&&enabled&&hints.some(m=>m.x===confirmCell.x&&m.y===confirmCell.y);
 if(!confirmValid)confirmCell=null;
 $('confirm-bar').hidden=!confirmValid;
}
// Draw the CPU game: the same board as online play, but the opponent
// is the CPU, so there is no timer, no presence, no rating and no
// banner. The player's stones are shown as あなた and the CPU's as
// CPU; while the CPU is thinking the state line says so.
function drawCpu(){
 const g=cpuGame;if(!g)return;
 $('reset').hidden=g.status!=='ended';
 const countsText=t('local_counts',{black:g.counts.black,white:g.counts.white});
 const who=g.currentPlayer===1?t('cpu_you'):t('cpu_name');
 const result=g.winner===null?t('result_none'):g.winner===0?t('result_draw'):t('result_win',{who:g.winner===1?t('cpu_you'):t('cpu_name')});
 tx($('state'),g.status==='ended'?countsText+' / '+t('state_ended',{result}):g.thinking?t('cpu_thinking'):countsText+' / '+t('state_turn',{who}));
 tx($('move-timer'),'');tx($('pool'),'');
 const shapeKey='shape_'+g.shape;
 tx($('shape-info'),g.shape&&g.shape!=='std'?t('shape_info',{shape:hasKey(lang,shapeKey)?t(shapeKey):t('shape_unknown')}):'');
 $('leave').disabled=false;
 $('rematch').hidden=g.status!=='ended';
 $('rematch-cancel').hidden=true;$('rematch-offer').hidden=true;
 tx($('rematch-line'),'');
 const enabled=g.status==='playing'&&g.currentPlayer===1&&!g.thinking;
 const hints=enabled?valid(g.board,1):[];
 renderBoard(g.board,hints,(x,y)=>applyCpuPlayerMove(x,y),playSettings.showKifu!==false?g.history:null);
 const confirmValid=confirmCell&&enabled&&hints.some(m=>m.x===confirmCell.x&&m.y===confirmCell.y);
 if(!confirmValid)confirmCell=null;
 $('confirm-bar').hidden=!confirmValid;
}
function draw(){
 $('lobby').hidden=!!session||subScreen!==null;$('game').hidden=!session;
 // Local two-player game: the lobby stays hidden and the game screen
 // stays open even though there is no server session.
 if(localGame){$('lobby').hidden=true;$('game').hidden=false;}
 // CPU play: the same, with this device's own engine as the opponent.
 if(cpuGame){$('lobby').hidden=true;$('game').hidden=false;}
 // Spectating: same shape as a game screen, but read-only.
 if(spectating){$('lobby').hidden=true;$('game').hidden=false;}
 // One screen at a time (test-play layout): the title first, then the
 // menu, then one screen per job. A game on hides every other screen
 // except settings, which can be opened mid-game and returns to it.
 // The back button shows everywhere except the title screen, and
 // mid-game only while settings is open.
 const inGame=!!session||!!localGame||!!cpuGame||!!spectating;
 document.body.dataset.screen=inGame?'game':screen;
 $('title').hidden=inGame||screen!=='title'||subScreen!==null;
 if(screen!=='menu'||inGame)$('lobby').hidden=true;
 $('play-screen').hidden=inGame||screen!=='play'||subScreen!==null;
 $('far-screen').hidden=inGame||screen!=='far'||subScreen!==null;
 $('twoplayer-screen').hidden=inGame||screen!=='twoplayer'||subScreen!==null;
 $('local-screen').hidden=inGame||screen!=='local'||subScreen!==null;
 $('cpu-screen').hidden=inGame||screen!=='cpu'||subScreen!==null;
 $('cpu-shape-screen').hidden=inGame||screen!=='cpushape'||subScreen!==null;
 $('mine').hidden=inGame||screen!=='record'||subScreen!==null;
 $('rankings').hidden=inGame||screen!=='rankings'||subScreen!==null;
 $('settings').hidden=screen!=='settings';
 if(screen==='settings')$('game').hidden=true;
 $('nav-back').hidden=inGame?screen!=='settings':screen==='title';
 $('leave').hidden=!!spectating;$('spectate-stop').hidden=!spectating;
 // A match fits in one viewport: lock the page scroll only while the
 // game screen itself is shown (settings opened mid-game can still
 // scroll), and size the board to the space left whenever a game
 // starts. Later size changes are caught by the ResizeObserver.
 document.body.classList.toggle('in-match',!$('game').hidden);
 if(!$('game').hidden&&!matchWasOn)fitBoard();
 matchWasOn=!$('game').hidden;
 // Banner ad on the game screen: shown while waiting for an opponent,
 // while a game is playing, and after it ends (only while connecting
 // is it hidden: the user does nothing while waiting, so there is no
 // accidental-tap risk). Spectating shows the same banner: a spectator
 // only watches, so there is no accidental-tap risk either. It sits
 // below the game section on desktop and at the very top on phones
 // (see the stylesheet), both far from the board, with 150px or more
 // between it and every button. It is a direct child of main, not of
 // the game section, so a short window can never clip it — but that
 // also means it needs the game screen itself to be showing, or it
 // would leak onto the settings screen when settings opens mid-game.
 // The other slots are filled whenever their screen is visible;
 // refreshAds() skips hidden and already-filled slots.
 // The game banner stays hidden while the ad slot is empty (AdSense
 // review pending): the ad script never loads, so the <ins> never gets
 // a data-ad-status and the stylesheet cannot hide the empty box — an
 // unhidden empty banner would eat 100px plus 182px of margins and
 // push the board out of the one viewport a match must fit in.
 const adGame=$('ad-game');if(adGame)adGame.hidden=!(adsEnabled()&&(session||spectating)&&!$('game').hidden&&(state?.status==='waiting'||state?.status==='playing'||state?.status==='ended'));
 refreshAds();
 // Local two-player: no room line, no presence (nobody is online), no
 // greetings (nobody to greet). The banner stays hidden: there is no
 // session, so the ad condition above already hides it. CPU play hides
 // the same parts (the opponent is this device, not a person).
 // The room line shows the password for a far-away room; a quick match
 // has no password, so the line (and its copy button) stays hidden.
 $('room-line').hidden=localGame!==null||cpuGame!==null||!session?.password;
 $('presence').hidden=localGame!==null||cpuGame!==null;
 $('greet-line').hidden=localGame!==null||cpuGame!==null;$('greet-panel').hidden=localGame!==null||cpuGame!==null;
 if(localGame){drawLocal();return;}
 if(cpuGame){drawCpu();return;}
 if(spectating){drawSpectate();return;}
 if(!session)return;
 $('room-password').textContent=session.password||'';
 $('reset').hidden=state?.status!=='ended'&&!manual;
 if(!state){tx($('state'),t('state_connecting'));updateMoveTimer();return;}
 tx($('state'),t('state_you',{you:names[session.color],black:state.counts.black,white:state.counts.white})+(state.status==='waiting'?t('state_waiting'):state.status==='ended'?t('state_ended',{result:state.winner===null?t('result_none'):state.winner===0?t('result_draw'):t('result_win',{who:names[state.winner]})})+(reasonText()?t('state_ended_reason',{reason:reasonText()}):''):t('state_turn',{who:names[state.currentPlayer]}))+(state.passed?.length?t('state_passed',{names:state.passed.map(p=>names[p]).join(t('list_sep'))}):''));
 updateMoveTimer();
 // The opponent's rating sits next to their colour (black / white) as
 // a guide for where to play; my own rating is never shown on this
 // screen (it lives on the record screen). state.ratings comes from
 // the server as [{rating,prov}|null, ...] per colour, or is absent
 // when the server has none yet.
 const opp=3-session.color;
 const oppRating=state.ratings?.[opp-1]?t('opp_rating',{rating:state.ratings[opp-1].rating,prov:state.ratings[opp-1].prov?t('provisional'):''}):'';
 // A nickname sits next to each colour's presence, and the opponent's
 // rating next to the opponent's colour. My own rating is never shown
 // here; my own nickname is, so I can check what the opponent sees.
 const nickPart=p=>state.nicknames?.[p-1]?' '+state.nicknames[p-1]:'';
 const presencePart=p=>(state.online?.[p-1]?t('online'):t('offline'))+nickPart(p)+(p===opp?oppRating:'');
 txNick($('presence'),t('presence_line',{black:presencePart(1),white:presencePart(2)}),[state.nicknames?.[0],state.nicknames?.[1]]);
 const enabled=state.status==='playing'&&state.currentPlayer===session.color&&ws?.readyState===1&&!pending&&!replaced;
 const hints=enabled?valid(state.board,session.color):[];
 renderBoard(state.board,hints,(x,y)=>send('move',{x,y}),playSettings.showKifu!==false?state.history:null);
 const shapeKey='shape_'+state.shape;
 tx($('shape-info'),state.shape&&state.shape!=='std'?t('shape_info',{shape:hasKey(lang,shapeKey)?t(shapeKey):t('shape_unknown')}):'');
 $('leave').disabled=!state||state.status==='ended'||ws?.readyState!==1||pending;
 // Confirm bar: shown only while a selected cell is still a legal move.
 const confirmValid=confirmCell&&enabled&&hints.some(m=>m.x===confirmCell.x&&m.y===confirmCell.y);
 if(!confirmValid)confirmCell=null;
 $('confirm-bar').hidden=!confirmValid;
 // Rematch controls: shown only after the game ends, and only in Relaxed
 // mode. Rated games (normal / fast) go back to room selection instead.
 // The pending request is also read from the server state, so it survives
 // a reconnect.
 if(state.status==='ended'&&typeof state.rematch==='number'){
  if(state.rematch===session.color){rematchWaiting=true;rematchOfferFrom=null;}
  else{rematchOfferFrom=state.rematch;rematchWaiting=false;}
 }
 const ended=state.status==='ended';
 const rematchable=ended&&state.mode==='slow';
 $('rematch').hidden=!rematchable||rematchWaiting||rematchOfferFrom!==null;
 $('rematch-cancel').hidden=!rematchable||!rematchWaiting;
 $('rematch-offer').hidden=!rematchable||rematchOfferFrom===null;
 if(rematchable&&rematchWaiting)tx($('rematch-line'),t('msg_rematch_waiting'));
 if(state?.status!=='ended')endRatingShown=false;
 // The game screen never shows my own rating (the record screen does):
 // at the end, play the end sound once and refresh my record.
 if(state?.status==='ended'&&!endRatingShown){endRatingShown=true;if(state.winner===session.color)playEndSe(true);else if(state.winner)playEndSe(false);fetchMe();fetchHighlights();}
}
function send(type,extra={}){
 if(!ws||ws.readyState!==1||!state||pending||replaced)return;
 pending=true;ws.send(JSON.stringify({type,id:crypto.randomUUID(),rev:state.rev,...extra}));
 clearTimeout(ackTimer);ackTimer=setTimeout(()=>{clearPending();say(t('msg_no_response'));$('reconnect').hidden=false;draw();},8000);draw();
}
// Server-down detection: the worker answers GET /api/health with
// {ok:true} and nothing else. It is only called when something already
// failed (a room create/join that could not reach the server, or a
// dropped socket), never on a timer, so it costs one request per
// failure at most. While the server is down the message line shows
// the server-down notice; a successful connection clears it again.
let serverDown=false,enterRetries=0,enterRetryTimer=null;
const HEALTH_TIMEOUT_MS=3000;
async function serverAlive(){
 try{
  const c=new AbortController(),to=setTimeout(()=>c.abort(),HEALTH_TIMEOUT_MS);
  const r=await fetch('api/health',{cache:'no-store',signal:c.signal});
  clearTimeout(to);return r.ok;
 }catch{return false;}
}
function showServerDown(){serverDown=true;say(t('server_down'));}
function clearServerDown(){serverDown=false;}
// How many people are playing right now: one light read of the
// spectate registry when the lobby opens, then once a minute while
// the lobby is visible. Never while playing, spectating or on a
// sub-screen, so it costs almost nothing.
let onlineTimer=null;
async function fetchOnlineCount(){
 if(session||localGame||cpuGame||subScreen!==null||spectating)return;
 if(screen!=='title'&&screen!=='menu')return;
 try{
  const r=await fetch('api/online');
  if(!r.ok)return;
  const d=await r.json();
  tx($('online-now'),t('online_now',{players:d.players??0}));
 }catch{}
}
function startOnlinePolling(){
 clearInterval(onlineTimer);
 fetchOnlineCount();
 onlineTimer=setInterval(fetchOnlineCount,60000);
}
// Spectating other people's games: the title screen lists the games in
// progress (from the server's registry); picking one opens a read-only
// socket to that room. The spectator sees the board, the move numbers,
// the timer and both players' nicknames and ratings, but cannot place a
// stone or touch the clock. When the game ends the socket closes and
// the screen goes back to the list.
let spectating=null; // {roomId}
let spectateWs=null;
function playerLabel(p,colour){
 if(p&&p.nick)return t('spectate_player',{nick:p.nick,rating:p.rating??'—',prov:p.prov?t('provisional'):' '});
 return names[colour];
}
async function loadSpectateList(){
 const list=$('spectate-list'),status=$('spectate-status');
 if(!list)return;
 tx(status,'');
 list.replaceChildren();
 try{
  const r=await fetch('api/spectate');
  if(!r.ok){tx(status,t('spectate_empty'));return;}
  const d=await r.json();
  if(!d.games||!d.games.length){tx(status,t('spectate_empty'));return;}
  for(const g of d.games){
   const b=document.createElement('button');
   const shapeText=g.shape&&g.shape!=='std'?(hasKey(lang,'shape_'+g.shape)?t('shape_'+g.shape):t('shape_unknown')):t('shape_option_std');
   txNick(b,t('spectate_entry',{black:playerLabel(g.black,1),white:playerLabel(g.white,2),mode:t('mode_'+g.mode),shape:shapeText}),[g.black?.nick,g.white?.nick]);
   b.onclick=()=>{playButtonSe();startSpectating(g.roomId);};
   list.append(b);
  }
 }catch{tx(status,t('spectate_empty'));}
}
function startSpectating(roomId){
 stopSpectating(true);
 spectating={roomId};
 showSubScreen(null);
 const u=new URL('api/rooms/'+roomId+'/watch',location.href);u.protocol=location.protocol==='https:'?'wss:':'ws:';
 const current=new WebSocket(u,['reversi']);spectateWs=current;
 current.onmessage=e=>{
  let m;try{m=JSON.parse(e.data);}catch{return;}
  if(m.type==='snapshot'||m.type==='delta'){
   if(m.type==='delta'&&state){
    if(m.rev!==state.rev+1){current.send(JSON.stringify({type:'sync'}));return;}
    for(const[x,y,v]of m.changes)state.board[y][x]=v;Object.assign(state,m);
   }else state=m;
   if(m.status==='playing'&&typeof m.moveMsLeft==='number')moveDeadlineAt=Date.now()+m.moveMsLeft;
   draw();
   if(m.status==='ended'){
    say(t('spectate_ended'));
    const key='spectate:'+roomId+':'+(state?.winner??'');
    const already=ceremonyKey===key;
    const hasResult=!!state&&state.winner!==null;
    if(!already&&hasResult){
     const word=ceremonyWordForColour(state.winner);
     showResultCeremony(key,state.board,word[0],word[1],()=>{if(spectating&&spectating.roomId===roomId)stopSpectating();});
    }
    // Never linger on an ended game: leave after the ceremony has had
    // time to show, or after 3 seconds when there is no ceremony.
    setTimeout(()=>{if(spectating&&spectating.roomId===roomId)stopSpectating();},already||hasResult?6000:3000);
   }
  }else if(m.type==='error'){say(t('msg_cannot_operate',{error:errorText(m.error)}));stopSpectating();}
 };
 current.onclose=()=>{if(spectating&&spectating.roomId===roomId)stopSpectating();};
 draw();
}
function stopSpectating(keepScreen){
 hideResultCeremony();
 if(spectateWs){spectateWs.onclose=null;try{spectateWs.close();}catch{}spectateWs=null;}
 spectating=null;state=null;moveDeadlineAt=null;
 if(!keepScreen){showSubScreen('spectate');draw();}
}
// The spectating view: the same board (with move numbers), the timer
// and both players' nicknames and ratings, but no room line, no
// greetings, no leave/rematch/reconnect — a spectator cannot
// touch anything. The game banner is shown (see draw()): a spectator
// only watches, so there is no accidental-tap risk.
function drawSpectate(){
 const s=state;
 $('room-line').hidden=true;
 $('presence').hidden=false;
 $('greet-line').hidden=true;$('greet-panel').hidden=true;
 $('reset').hidden=true;
 $('rematch').hidden=true;$('rematch-cancel').hidden=true;$('rematch-offer').hidden=true;
 $('reconnect').hidden=true;
 $('confirm-bar').hidden=true;
 if(!s){tx($('state'),t('state_connecting'));updateMoveTimer();return;}
 const countsText=t('local_counts',{black:s.counts.black,white:s.counts.white});
 tx($('state'),s.status==='ended'?countsText+' / '+t('state_ended',{result:s.winner===null?t('result_none'):s.winner===0?t('result_draw'):t('result_win',{who:names[s.winner]})}):countsText+' / '+t('state_turn',{who:names[s.currentPlayer]}));
 updateMoveTimer();
 const part=p=>{const n=s.nicknames?.[p-1];const r=s.ratings?.[p-1];return n?t('spectate_player',{nick:n,rating:r?r.rating:'—',prov:r?.prov?t('provisional'):' '}):names[p];};
 txNick($('presence'),part(1)+t('list_sep')+part(2),[s.nicknames?.[0],s.nicknames?.[1]]);
 const shapeKey='shape_'+s.shape;
 tx($('shape-info'),s.shape&&s.shape!=='std'?t('shape_info',{shape:hasKey(lang,shapeKey)?t(shapeKey):t('shape_unknown')}):'');
 renderBoard(s.board,[],()=>{},playSettings.showKifu!==false?s.history:null);
}
function connect(){
 clearTimeout(timer);if(!session)return;
 const old=ws;if(old){old.onclose=null;old.close();}
 manual=false;clearPending();$('reconnect').hidden=true;
 const u=new URL('api/rooms/'+session.roomId+'/socket',location.href);u.protocol=location.protocol==='https:'?'wss:':'ws:';
 const current=new WebSocket(u,['reversi','auth.'+session.token]);ws=current;
 const deadline=setTimeout(()=>{if(current.readyState!==1)current.close();},10000);
 current.onopen=()=>{clearTimeout(deadline);clearServerDown();say(t('msg_connected'));};
 current.onmessage=e=>{
  let m;try{m=JSON.parse(e.data);}catch{return;}
  const wasEnded=state?.status==='ended';
  if(m.type==='snapshot'){state=m;clearPending();if(wasEnded&&m.status==='playing')onNewGame();}
  else if(m.type==='delta'){
   if(!state||m.rev!==state.rev+1){current.send(JSON.stringify({type:'sync'}));return;}
   for(const[x,y,v]of m.changes)state.board[y][x]=v;Object.assign(state,m);clearPending();
   if(wasEnded&&m.status==='playing')onNewGame();
   if(m.changes?.length){playPlaceSe();if(m.changes.length>1)setTimeout(playFlipSe,120);}
  }else if(m.type==='presence'){if(state)state.online=m.online;}
  else if(m.type==='greet'){showGreet(m.from,m.text,m.lang);}
  else if(m.type==='rematch-offer'){
   if(m.from===session.color){rematchWaiting=true;rematchOfferFrom=null;}
   else{rematchOfferFrom=m.from;rematchWaiting=false;}
  }
  else if(m.type==='rematch-declined'){
   rematchWaiting=false;rematchOfferFrom=null;
   tx($('rematch-line'),m.from===session.color?t('msg_rematch_cancelled'):t('msg_rematch_declined'));
  }
  else if(m.type==='error'){clearPending();say(t('msg_cannot_operate',{error:errorText(m.error)}));if(m.error==='OPPONENT_OFFLINE')rematchWaiting=false;}
  if(m.type==='snapshot'||m.type==='delta')moveDeadlineAt=(m.status==='playing'&&typeof m.moveMsLeft==='number')?Date.now()+m.moveMsLeft:null;
  draw();
  // The game just ended (a snapshot or delta that moved it from
  // playing to ended): count the stones and show the result. A
  // snapshot of a game that already ended (a reconnect) shows it too.
  if((m.type==='snapshot'||m.type==='delta')&&state?.status==='ended'&&!wasEnded&&state.winner!==null&&session){
   const word=ceremonyWordForYou(state.winner,session.color);
   if(word)showResultCeremony('online:'+session.roomId+':'+state.winner,state.board,word[0],word[1]);
  }
 };
 current.onerror=()=>say(t('msg_no_connection'));
 current.onclose=async e=>{
  clearTimeout(deadline);clearPending();
  if(e.code===4001){
   // Another screen opened this game: this screen is replaced. It must
   // not reconnect (that would fight the new screen) and cannot move any
   // more; the board is already disabled because the socket is closed.
   replaced=true;manual=true;say(t('msg_replaced'));$('reconnect').hidden=true;
  }
  else if(e.code===1008||e.code===1000||state?.status==='ended'){manual=true;say(t('msg_conn_closed'));$('reconnect').hidden=false;}
  else if(retries<5){const delay=Math.min(15000,1000*2**retries++)+Math.random()*500;
   // One light probe per drop (no polling): if the worker answers, only
   // this socket dropped; if it does not, the server itself is down.
   // Worst case the five probes add 15 seconds to the backoff, so the
   // whole retry series still fits inside the 90-second grace.
   if(!(await serverAlive()))showServerDown();else say(t('msg_reconnecting'));
   timer=setTimeout(connect,delay);}
  else{manual=true;if(serverDown)say(t('server_down'));else say(t('msg_reconnect_stopped'));$('reconnect').hidden=false;}
  draw();
 };draw();
}
// Turnstile (robot check) for room creation. The site key is public —
// it is embedded in the page, like the AdSense publisher ID — and the
// secret key is never used here; only the server holds it. The server
// requires a fresh token (action 'reversi') for POST /api/rooms and
// POST /api/rooms/quick when BOT_MODE is required, so each press of
// 対戦する asks the widget for a new token. A token is single-use: once
// it is sent it is forgotten, and the next press asks for a new one.
// On localhost the server does not check, so a missing Turnstile
// script there simply means no token is sent.
const TURNSTILE_SITEKEY='0x4AAAAAAGDXLO6Yg5TYEdjI';
const TURNSTILE_ACTION='reversi';
// A token from the widget's automatic run is only trusted briefly:
// Turnstile tokens go stale, so anything older than a minute is
// discarded and a fresh one is asked for instead.
const TURNSTILE_TOKEN_MAX_AGE_MS=60000;
const TURNSTILE_TIMEOUT_MS=60000;
// One widget per room-creation screen (quick match and far-away): the
// challenge only runs while its widget is visible, so each screen has
// its own. Each entry holds the widget id, a fresh unused token from
// the automatic run (if any), and the waiters for a token asked for
// by turnstile.execute().
const turnstileWidgets={};
let turnstileScriptState='loading'; // 'loading' | 'ready' | 'failed'
function turnstileWidgetFor(containerId){
 return turnstileWidgets[containerId]||null;
}
function turnstileVisibleWidget(){
 // The press comes from the screen that is open: use its widget.
 if(!$('far-screen').hidden)return turnstileWidgetFor('turnstile-far');
 if(!$('play-screen').hidden)return turnstileWidgetFor('turnstile-quick');
 return turnstileWidgetFor('turnstile-quick')||turnstileWidgetFor('turnstile-far');
}
function turnstileOnToken(slot,token){
 if(!token)return;
 // A waiter asked for a fresh token with execute(): hand it over
 // directly instead of storing it, so it can never be used twice.
 if(slot.waiters.length){const w=slot.waiters.shift();clearTimeout(w.timer);w.resolve(token);return;}
 slot.token=token;slot.at=Date.now();
}
function turnstileOnError(slot){
 slot.token=null;slot.at=0;
 while(slot.waiters.length){const w=slot.waiters.shift();clearTimeout(w.timer);w.reject(Error('CHALLENGE_REQUIRED'));}
}
function turnstileRenderAll(){
 if(!window.turnstile)return false;
 let any=false;
 for(const id of ['turnstile-quick','turnstile-far']){
  if(turnstileWidgets[id])continue;
  const el=$(id);if(!el)continue;
  const slot={widgetId:null,token:null,at:0,waiters:[]};
  slot.widgetId=window.turnstile.render(el,{
   sitekey:TURNSTILE_SITEKEY,action:TURNSTILE_ACTION,
   callback:token=>{turnstileOnToken(slot,token);},
   'expired-callback':()=>{slot.token=null;slot.at=0;},
   'error-callback':()=>{turnstileOnError(slot);},
  });
  turnstileWidgets[id]=slot;any=true;
 }
 return any;
}
function turnstileWaitReady(){
 if(turnstileScriptState==='ready')return Promise.resolve(true);
 if(turnstileScriptState==='failed')return Promise.resolve(false);
 return new Promise(resolve=>{
  const start=Date.now();
  const iv=setInterval(()=>{
   if(turnstileScriptState!=='loading'||Date.now()-start>10000){clearInterval(iv);resolve(turnstileScriptState==='ready');}
  },100);
 });
}
function initTurnstile(){
 // The script tag is in index.html (async): wait for it, then render
 // both widgets. If it never arrives (offline, blocked), room
 // creation on a real host is stopped with a clear message instead.
 if(window.turnstile){turnstileScriptState='ready';turnstileRenderAll();return;}
 let waited=0;
 const iv=setInterval(()=>{
  waited+=100;
  if(window.turnstile){clearInterval(iv);turnstileScriptState='ready';turnstileRenderAll();}
  else if(waited>=10000){clearInterval(iv);turnstileScriptState='failed';}
 },100);
}
// The short-lived Turnstile response for one room creation. Returns a
// fresh token (action 'reversi'), or undefined on localhost where the
// server does not check. Throws CHALLENGE_REQUIRED when no token can
// be had, so the press is stopped with the same message the server
// would give for a missing token.
window.reversiChallenge=async function(){
 const local=['localhost','127.0.0.1'].includes(location.hostname);
 if(!await turnstileWaitReady()){
  if(local)return undefined;
  throw Error('CHALLENGE_REQUIRED');
 }
 const slot=turnstileVisibleWidget();
 if(!slot||slot.widgetId==null){
  if(local)return undefined;
  throw Error('CHALLENGE_REQUIRED');
 }
 // A fresh token from the widget's automatic run: use it once.
 if(slot.token&&Date.now()-slot.at<TURNSTILE_TOKEN_MAX_AGE_MS){
  const token=slot.token;slot.token=null;slot.at=0;return token;
 }
 slot.token=null;slot.at=0;
 // No fresh token: ask the widget for a new one. In managed mode this
 // usually answers at once without the player doing anything.
 // A token is single-use: once it is sent it is spent, and asking the
 // widget again without clearing it can hand back the spent token.
 // Reset first so the next run makes a genuinely fresh token.
 return new Promise((resolve,reject)=>{
  const waiter={resolve,reject,timer:null};
  waiter.timer=setTimeout(()=>{
   const i=slot.waiters.indexOf(waiter);
   if(i>=0)slot.waiters.splice(i,1);
   reject(Error('CHALLENGE_REQUIRED'));
  },TURNSTILE_TIMEOUT_MS);
  slot.waiters.push(waiter);
  try{window.turnstile.reset(slot.widgetId);}catch{}
  // Reset alone re-runs the challenge in managed mode; execute() is a
  // second nudge in case it does not. If execute() throws because a
  // run is already going, leave the waiter in place: the run that is
  // going will answer it through the callback.
  try{window.turnstile.execute(slot.widgetId);}catch{}
 });
};
// Far-away two-player: one password field, one button. The same
// password joins the waiting room with it or makes a room with it
// when there is none, so the player never has to choose between
// creating and joining. The password is only used here: the online
// screen pairs strangers with no password (quick match).
async function enter(isRetry=false){
 if(requesting)return;
 // A manual attempt starts a fresh series: drop any pending automatic
 // retry and its count. A scheduled retry keeps the count instead.
 if(!isRetry){enterRetries=0;clearTimeout(enterRetryTimer);}
 playButtonSe();const password=$('far-password').value;
 if(!validPassword(password)){say(t('msg_bad_password'));return;}
 requesting=true;$('far-go').disabled=true;
 try{
  // Integrators can provide a short-lived Turnstile response through this callback.
  const challenge=typeof window.reversiChallenge==='function'?await window.reversiChallenge():undefined;
  const res=await fetch('api/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({challenge,password,pid:pid||undefined,nickname:nickname||undefined,mode:$('far-mode').value,shape:$('far-shape').value})});
  // A response that is not JSON (a proxy error page, for example) means
  // the server did not really answer, even though the fetch itself
  // succeeded: treat it like a failed connection, not a room error.
  let m=null,jsonOk=true;try{m=await res.json();}catch{jsonOk=false;}
  if(!jsonOk||!m||typeof m!=='object')throw Error('SERVER_ERROR');
  if(!res.ok)throw Error(m.error);
  session={...m,password};state=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;confirmCell=null;replaced=false;enterRetries=0;clearTimeout(enterRetryTimer);clearServerDown();save();retries=0;connect();
 }catch(e){
  if(e.message==='DAILY_ROOM_LIMIT'){say(t('msg_daily_limit'));}
  else if(e.message==='ROOM_PLAYING'){say(t('msg_room_playing'));}
  else if(e.message==='SERVER_ERROR'||e instanceof TypeError){
   // The request never reached a working server: confirm with the
   // light health probe, then show the server-down notice and retry
   // a few times instead of the generic failure message.
   if(!(await serverAlive())){showServerDown();scheduleEnterRetry();}
   else say(t('msg_enter_failed',{error:errorText(e.message)}));
  }
  else say(t('msg_enter_failed',{error:errorText(e.message)}));
 }finally{requesting=false;$('far-go').disabled=false;}
}
// Automatic retry after a failed entry, only while the server is
// down: three tries, five seconds apart, then stop and leave the notice
// (and the buttons) for a manual retry.
function scheduleEnterRetry(){
 clearTimeout(enterRetryTimer);
 if(enterRetries>=3)return;
 enterRetryTimer=setTimeout(()=>{enterRetries++;enter(true);},5000);
}
// Quick match (no password): the online screen pairs the player with
// whoever else is waiting with the same mode and board shape. The
// first press waits; a poll every 5 seconds asks whether the match
// is made. The wait lasts 10 minutes, like a waiting room; leaving
// the screen cancels the wait on the server. A failed poll keeps
// polling (the next poll retries), and the server-down notice clears
// as soon as a poll answers again.
const QUICK_WAIT_MS=300000,QUICK_POLL_MS=5000;
let quickWaiting=false,quickWaitStartedAt=0,quickPollTimer=null,quickRetries=0,quickRetryTimer=null,quickSecsTimer=null;
function updateQuickWaitSecs(){
 const el=$('quick-wait-secs');if(!el)return;
 const s=Math.max(0,Math.floor((Date.now()-quickWaitStartedAt)/1000));
 el.textContent=t('quick_wait_secs',{s});
}
function stopQuickWait(){
 quickWaiting=false;clearInterval(quickPollTimer);quickPollTimer=null;
 clearInterval(quickSecsTimer);quickSecsTimer=null;
 const w=$('quick-waiting');if(w)w.hidden=true;
 const secs=$('quick-wait-secs');if(secs)secs.textContent='';
 const go=$('play-go');if(go)go.disabled=false;
}
async function cancelQuick(){
 if(!quickWaiting)return;
 stopQuickWait();
 try{await fetch('api/rooms/quick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cancel:true,pid:pid||undefined})});}catch{}
 say('');
}
async function pollQuick(){
 if(!quickWaiting)return;
 if(Date.now()-quickWaitStartedAt>=QUICK_WAIT_MS){
  await cancelQuick();say(t('quick_timeout'));return;
 }
 let m=null,jsonOk=true;
 try{
  const res=await fetch('api/rooms/quick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({poll:true,pid:pid||undefined})});
  try{m=await res.json();}catch{jsonOk=false;}
  if(!jsonOk||!m||typeof m!=='object')throw Error('SERVER_ERROR');
  if(!res.ok)throw Error(m.error);
 }catch(e){
  // The server did not answer: keep polling (the next poll retries)
  // and say so, instead of dropping the wait over one failed poll.
  if(e.message==='SERVER_ERROR'||e instanceof TypeError){showServerDown();return;}
  stopQuickWait();say(t('msg_enter_failed',{error:errorText(e.message)}));return;
 }
 if(m.status==='matched'&&m.roomId){
  stopQuickWait();clearServerDown();
  // An opponent was found: sound the start so the wait is heard even
  // when the player is looking away.
  playSe(SE_FIXED.win);
  session={roomId:m.roomId,token:m.token,color:m.color};state=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;confirmCell=null;replaced=false;save();retries=0;connect();
 }else if(m.status==='waiting'){
  // Still in line: nothing to do until the next poll.
 }else{
  // The wait is gone on the server (expired or cancelled elsewhere).
  stopQuickWait();say(t('quick_timeout'));
 }
}
async function enterQuick(isRetry=false){
 if(requesting)return;
 if(!isRetry){quickRetries=0;clearTimeout(quickRetryTimer);}
 playButtonSe();requesting=true;$('play-go').disabled=true;
 try{
  const challenge=typeof window.reversiChallenge==='function'?await window.reversiChallenge():undefined;
  const res=await fetch('api/rooms/quick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({challenge,mode:$('mode').value,shape:$('shape').value,pid:pid||undefined,nickname:nickname||undefined})});
  let m=null,jsonOk=true;try{m=await res.json();}catch{jsonOk=false;}
  if(!jsonOk||!m||typeof m!=='object')throw Error('SERVER_ERROR');
  if(!res.ok)throw Error(m.error);
  if(m.status==='matched'&&m.roomId){
   // Matched at once: sound the start like the poll path does.
   playSe(SE_FIXED.win);
   session={roomId:m.roomId,token:m.token,color:m.color};state=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;confirmCell=null;replaced=false;quickRetries=0;clearTimeout(quickRetryTimer);clearServerDown();save();retries=0;connect();
  }else{
   // Waiting for an opponent: poll every 5 seconds until the match
   // is made or the 5 minutes run out.
   quickWaiting=true;quickWaitStartedAt=Date.now();
   const w=$('quick-waiting');if(w)w.hidden=false;
   updateQuickWaitSecs();
   clearInterval(quickSecsTimer);quickSecsTimer=setInterval(updateQuickWaitSecs,1000);
   clearInterval(quickPollTimer);quickPollTimer=setInterval(pollQuick,QUICK_POLL_MS);
  }
 }catch(e){
  if(e.message==='DAILY_ROOM_LIMIT'){say(t('msg_daily_limit'));}
  else if(e.message==='SERVER_ERROR'||e instanceof TypeError){
   // The request never reached a working server: show the notice and
   // retry a few times instead of the generic failure message.
   showServerDown();scheduleQuickRetry();
  }
  else say(t('msg_enter_failed',{error:errorText(e.message)}));
 }finally{requesting=false;if(!quickWaiting)$('play-go').disabled=false;}
}
// Automatic retry after a failed quick entry, only while the server is
// down: three tries, five seconds apart, then stop and leave the notice
// (and the buttons) for a manual retry.
function scheduleQuickRetry(){
 clearTimeout(quickRetryTimer);
 if(quickRetries>=3)return;
 quickRetryTimer=setTimeout(()=>{quickRetries++;enterQuick(true);},5000);
}
$('cpu-play').onclick=()=>{playButtonSe();showScreen('cpu');};
document.querySelectorAll('#cpu-levels .cpu-level').forEach(b=>{b.onclick=()=>{playButtonSe();cpuLevel=+b.dataset.level;showScreen('cpushape');};});
$('cpu-start').onclick=()=>{playButtonSe();startCpuGame();};
$('play-two').onclick=()=>{playButtonSe();showScreen('twoplayer');};
$('play-online').onclick=()=>{playButtonSe();showScreen('play');};
$('play-nearby').onclick=()=>{playButtonSe();showScreen('local');};
$('play-far').onclick=()=>{playButtonSe();showScreen('far');};
$('local-start').onclick=()=>{playButtonSe();startLocalGame();};
$('play-go').onclick=()=>enterQuick();
$('far-go').onclick=()=>enter();
$('quick-cancel').onclick=()=>{playButtonSe();cancelQuick();showScreen('menu');};
$('start').onclick=()=>{playButtonSe();showScreen('menu');};
$('back-to-pare').onclick=()=>{location.href='https://atugari.github.io/';};
$('record-open').onclick=()=>{playButtonSe();showScreen('record');};
$('rankings-open').onclick=()=>{playButtonSe();showScreen('rankings');};
$('nav-settings').onclick=()=>{
 playButtonSe();
 if(session||localGame||cpuGame||spectating)settingsReturn='game';
 else if(screen==='play'||screen==='far'||screen==='local'||screen==='twoplayer'||screen==='cpu'||screen==='cpushape')settingsReturn=screen;
 showScreen('settings');
};
$('nav-back').onclick=()=>{
 playButtonSe();
 if(screen==='settings'&&settingsReturn){const r=settingsReturn;settingsReturn=null;showScreen(r);return;}
 if(subScreen!==null){showSubScreen(null);return;}
 if(screen==='menu'){showScreen('title');return;}
 if(screen==='play'){cancelQuick();showScreen('menu');return;}
 if(screen==='far'||screen==='local'){showScreen('twoplayer');return;}
 if(screen==='twoplayer'){showScreen('menu');return;}
 if(screen==='cpu'){showScreen('menu');return;}
 if(screen==='cpushape'){showScreen('cpu');return;}
 showScreen('menu');
};
$('spectate-open').onclick=()=>{playButtonSe();showSubScreen('spectate');};
$('spectate-back').onclick=()=>{playButtonSe();showSubScreen(null);};
$('spectate-stop').onclick=()=>{playButtonSe();stopSpectating();};
$('copy').onclick=async()=>{if(!session?.password)return;try{await navigator.clipboard.writeText(session.password);say(t('msg_copied'));}catch{say(t('msg_copy_manual'));}};
$('leave').onclick=()=>{hideResultCeremony();if(localGame){playButtonSe();exitLocalGame();return;}if(cpuGame){playButtonSe();exitCpuGame();return;}if(confirm(t('confirm_leave'))){playButtonSe();send('leave');}};
$('rematch').onclick=()=>{playButtonSe();if(localGame){startLocalGame();return;}if(cpuGame){startCpuGame();return;}sendRaw({type:'rematch'});};
$('rematch-accept').onclick=()=>{playButtonSe();rematchOfferFrom=null;sendRaw({type:'rematch'});};
$('rematch-decline').onclick=()=>{playButtonSe();rematchOfferFrom=null;sendRaw({type:'rematch-decline'});draw();};
$('rematch-cancel').onclick=()=>{playButtonSe();rematchWaiting=false;sendRaw({type:'rematch-decline'});draw();};
$('confirm-place').onclick=()=>{if(!confirmCell)return;const c=confirmCell;confirmCell=null;if(localGame){applyLocalMove(c.x,c.y);return;}if(cpuGame){applyCpuPlayerMove(c.x,c.y);return;}send('move',{x:c.x,y:c.y});};
$('confirm-cancel').onclick=()=>{confirmCell=null;draw();};
let lastManualConnect=0;
$('reconnect').onclick=()=>{const now=Date.now();if(now-lastManualConnect<3000)return;lastManualConnect=now;retries=0;playButtonSe();connect();};
$('reset').onclick=()=>{hideResultCeremony();playButtonSe();clearTimeout(timer);clearTimeout(ackTimer);clearTimeout(enterRetryTimer);serverDown=false;stopQuickWait();clearTimeout(quickRetryTimer);clearTimeout(cpuTimer);if(ws){ws.onclose=null;ws.close();}session=null;state=null;localGame=null;cpuGame=null;moveDeadlineAt=null;endRatingShown=false;rematchWaiting=false;rematchOfferFrom=null;confirmCell=null;replaced=false;const rl=$('rematch-line');if(rl)rl.textContent='';try{sessionStorage.removeItem(KEY);}catch{}say('');showScreen('menu');fetchMe();fetchRankings();};
initAds();initTurnstile();if(session)connect();else draw();applyLang();fetchMe();fetchRankings();fetchHighlights();startOnlinePolling();
document.querySelectorAll('#rankings [data-scope]').forEach(b=>b.onclick=()=>{playButtonSe();rankScope=b.dataset.scope;renderScopeButtons();fetchRankings();});
$('rank-filter').onchange=()=>{playButtonSe();const v=$('rank-filter').value;rankFilter=v==='all'?null:+v;fetchRankings();};
